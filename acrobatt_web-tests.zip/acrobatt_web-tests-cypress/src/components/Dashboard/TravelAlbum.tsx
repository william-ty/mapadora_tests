import { Box, Button, InputAdornment, TextField } from "@mui/material";
import api from "api/api";
import Album from "components/Album/Album";
import { Travel } from "model/Travel";
import React from "react";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { useParams } from "react-router";
import { ContentCopy } from "@mui/icons-material";
import { useMainData } from "provider/MainDataProvider";

export const TravelAlbum = () => {
  const { showFeedback } = useMainData();
  const queryClient = useQueryClient();
  const params = useParams();
  const idTravel = params.idTravel;

  const {
    isLoading: isLoading,
    isError: isError,
    data: travelData,
  } = useQuery(["travelData", idTravel], () => {
    return api.get({ route: `travel/${idTravel}`, hasToken: true });
  });

  const updateTravel = useMutation(api.update, {
    onSuccess: (newTravelData, { id }) => {
      queryClient.setQueryData<Travel>(
        ["travelData", idTravel],
        (travelData) => newTravelData
      );
    },
  });

  const copyToClipboard = (newClip: string) => {
    navigator.clipboard.writeText(newClip);
    showFeedback("Texte copié avec succès !");
  };

  return (
    <>
      <Box sx={{ display: "flex", justifyContent: "flex-end", my: 2 }}>
        {travelData && travelData.is_album_public ? (
          <>
            <TextField
              id="input-with-icon-textfield"
              label="Lien de partage"
              defaultValue={`http://localhost:3000/view/${travelData.path_uid}/album`}
              //   defaultValue={`${window.location.protocol}://${window.location.hostname}/view/${travelData.path_uid}/album`}
              disabled
              sx={{ width: 400 }}
              onClick={() =>
                copyToClipboard(
                  `http://localhost:3000/view/${travelData.path_uid}/album`
                )
              }
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <ContentCopy />
                  </InputAdornment>
                ),
              }}
              variant="standard"
            />
            <Button
              variant="contained"
              onClick={() => {
                updateTravel.mutate({
                  route: Travel.routeName,
                  id: travelData?.id!,
                  body: {
                    ...travelData,
                    is_album_public: false,
                  },
                });
              }}
              color="error"
            >
              Révoquer le partage
            </Button>
          </>
        ) : (
          <Button
            variant="contained"
            onClick={() => {
              updateTravel.mutate({
                route: Travel.routeName,
                id: travelData?.id!,
                body: {
                  ...travelData,
                  is_album_public: true,
                },
              });
            }}
          >
            Partager mon album
          </Button>
        )}
      </Box>
      <Album />
    </>
  );
};
