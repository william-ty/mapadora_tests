

import {Trip} from '../../src/model/Trip'

    const createTrip = () => {
  
return new Trip(      {
          id: 10,
          createdAt: "2022-03-20T19:34:45.475Z",
          updatedAt: "2022-03-20T19:34:45.475Z",
          id_transportmode:1,
          id_element: 33,
      })
  
  }
  
  export {createTrip};