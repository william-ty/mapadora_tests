import { Typography } from "@mui/material";

export const Roger = () => {
  return <Typography>Hello, c'est moi Roger !</Typography>;
};
