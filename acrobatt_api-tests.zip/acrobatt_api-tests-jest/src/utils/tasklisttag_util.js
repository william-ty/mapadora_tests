let afterCreateTaskListTag = async (sequelize, instance) => {
  const element = await sequelize.models.Element.findOne({
    where: {
      id: instance.id_element
    }
  });
  const itinerary = await sequelize.models.Itinerary.findOne({
    include: [{
      model: sequelize.models.Element, required: true, as: "element_itinerary",
      where: {
        id_travel: element.id_travel
      }
    }]
  });
  const taskList = await sequelize.models.TaskList.findByPk(itinerary.id);
  const taskListId =  taskList.id 

  await sequelize.models.TaskListTag.create({
    name: element.name,
    id_task_list: taskListId
  });
}

module.exports = { afterCreateTaskListTag }