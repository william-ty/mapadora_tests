import { Box, Typography } from "@mui/material";
import React from "react";
import { InterestPointsDragGroup } from "../InterestPointsDragGroup";

export const InterestPointList = () => {
  return (
    <>
      <Box sx={{ backgroundColor: "primary.lightest", padding: 1, mb: 1, borderRadius: "4px" }} >
        <Typography textTransform="uppercase" color="primary.darker" ml={1} fontWeight="medium" variant="h6">Liste des points d'intérêt</Typography>
      </Box>
      <InterestPointsDragGroup />
    </>
  );
};
