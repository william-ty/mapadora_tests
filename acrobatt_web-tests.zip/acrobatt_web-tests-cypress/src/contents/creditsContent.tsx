export const homeCredits = [
  {
    primaryContent: "Image partie inspirez-vous",
    secondaryContent: "pixabay.com",
    link: "https://pixabay.com/fr/photos/polyn%c3%a9sie-polyn%c3%a9sie-fran%c3%a7ais-tahiti-3021072/",
  },
  {
    primaryContent: "Image partie planifiez",
    secondaryContent: "pixabay.com",
    link: "https://imagefinder.co/photo/map-road-51d96",
  },
  {
    primaryContent: "Image partie voyagez",
    secondaryContent: "pixabay.com",
    link: "https://pixabay.com/fr/photos/lac-montagnes-nature-en-plein-air-6627781/",
  },
  {
    primaryContent: "Image partie partagez",
    secondaryContent: "picjumbo.com",
    link: "https://picjumbo.com/friends-using-their-smartphones-to-find-the-right-way/",
  },
  {
    primaryContent: "Image partie gérez vos dépenses",
    secondaryContent: "pixabay.com",
    link: "https://pixabay.com/fr/vectors/pi%c3%a8ces-de-monnaie-argent-financier-3344603/",
  },
  {
    primaryContent: "Image de van",
    secondaryContent: "pixabay.com",
    link: "https://pixabay.com/fr/illustrations/auto-transport-v%c3%a9hicule-autobus-4025379/",
  },
];
