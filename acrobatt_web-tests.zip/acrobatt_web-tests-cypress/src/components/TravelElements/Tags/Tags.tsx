import React, { ChangeEvent, FormEvent, useState } from "react";
import { TagList } from "./TagList";
import { AddTagForm } from "./AddTagForm";
import { AddTag, HandleUpdate } from "./TagListItem";
import { Box, Typography } from "@mui/material";
import { useQuery, useQueryClient, useMutation } from "react-query";
import { useParams } from "react-router-dom";
import { TaskListTag } from "model/TaskListTag";
import api from "api/api";
import { TagHeader } from "./TagHeader";


export const Tags: React.FC = () => {

  const queryClient = useQueryClient();
  const { idTravel } = useParams();
  const id_travel = parseInt(idTravel!);

  const [newTag, setNewTag] = useState<TaskListTag>();
  const [newTagName, setNewTagName] = useState<string>("");

  const handleNameChange = (e: ChangeEvent<HTMLInputElement>) => {
    setNewTagName(e.target.value);
  };

  const handleSubmit = (e: FormEvent<HTMLButtonElement>) => {
    e.preventDefault();
    newTagName && addTag(new TaskListTag({ name: newTagName }));
    setNewTagName("");
  };

  const {
    isLoading: tagsIsLoading,
    isError: tagsIsError,
    data: tags,
  } = useQuery<TaskListTag[], Error>(
    ["tags", id_travel],
    () => api.get({ route: TaskListTag.routeName, idTravel: id_travel }),
    { structuralSharing: false }
  );

  const createTag = useMutation(api.create, {
    onSuccess: (tag) => {
      queryClient.setQueryData<TaskListTag[]>(["tags", id_travel], (tags) =>
        tags ? [...tags, tag] : []
      );
    },
  });

  const addTag: AddTag = newTag => {
    console.log(newTag)
    createTag.mutate({
      route: TaskListTag.routeName,
      body: newTag,
      idTravel: id_travel,
    });
  };

  const deleteTag = useMutation(api.delete, {
    onSuccess: (tag, { id }) => {
      queryClient.setQueryData<TaskListTag[]>(["tags", id_travel], (tags) =>
        tags!.filter((t) => t.id !== id)
      );
    },
  });
  const updateTag = useMutation(api.update, {
    onSuccess: (tag, { id }) => {
      queryClient.setQueryData<TaskListTag[]>(["tags", id_travel], (tags) =>
        tags!.map((t) => (t.id === id ? tag : t))
      );
    },
  });
  // const [tags, setTags] = useState<Array<Tag>>(initialTags);

  const handleDelete = (selectedTag: TaskListTag) => {
    console.log(selectedTag);
    deleteTag.mutate({
      route: TaskListTag.routeName,
      id: selectedTag.id!,
      idTravel: id_travel,
    });
  }

  const handleUpdate: HandleUpdate = selectedTag => {
    console.log(selectedTag);
    updateTag.mutate({
      route: TaskListTag.routeName,
      id: selectedTag?.id!,
      body: selectedTag,
      idTravel: id_travel,
    });
  };

  return (
    <Box>
      <Typography variant="h4" sx={{ my: 2 }}>Labels</Typography>
      <AddTagForm addTag={addTag} handleNameChange={handleNameChange} handleSubmit={handleSubmit} newTagName={newTagName} />
      <TagHeader />
      <TagList
        tags={tags}
        handleDelete={handleDelete}
        handleUpdate={handleUpdate}
      />
    </Box>
  );
};