import { Visibility } from "@mui/icons-material";
import {
  Button,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Typography,
  Box,
  Divider,
} from "@mui/material";
import { TripStep } from "components/MapItems/DraggableListItem";
import React, { useEffect, useState } from "react";
import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import { Trip } from "../../../model/Trip";
import { useData } from "../../../provider/DataProvider";
import { DocumentList } from "../DocumentList";
import { TripGroup } from "../TripGroup";

export const TripDetail = () => {
  const navigate = useNavigate();
  // const { selectedId } = useData();
  const { id } = useParams();
  const {
    tripSteps,
    isEditable,
  }: { tripSteps: TripStep[]; isEditable: boolean } = useOutletContext();

  const [selectedTripStep, setSelectedTripStep] = useState<TripStep>();

  useEffect(() => {
    tripSteps.forEach((tripStep: TripStep) => {
      tripStep?.trip?.id?.toString() === id && setSelectedTripStep(tripStep);
      tripStep?.trip?.id?.toString() === id && console.log(tripStep);
    });
  }, [id, tripSteps]);

  useEffect(() => {
    console.log(selectedTripStep);
  }, [selectedTripStep]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: "accent.lightest",
          padding: 1,
          mb: 1,
          borderRadius: "4px",
        }}
      >
        <Typography
          textTransform="uppercase"
          color="accent.darker"
          ml={1}
          fontWeight="medium"
          variant="h6"
        >
          Details du trajet «{selectedTripStep?.trip?.element?.name}»
        </Typography>
      </Box>
      <Box
        sx={{
          backgroundColor: "accent.lightest",
          padding: 2,
          borderRadius: "4px",
        }}
        display="flex"
        flexDirection="column"
      >
        <Typography variant="h6" sx={{ mb: 1 }}>
          Informations
        </Typography>
        <Typography
          textTransform="capitalize"
          variant="body1"
          style={styles.title}
        >
          — étape de départ :
        </Typography>
        <Typography
          textTransform="capitalize"
          variant="body1"
          style={styles.info}
        >
          {selectedTripStep?.departure?.element?.name}
        </Typography>
        <Typography
          textTransform="capitalize"
          sx={{ mt: 1 }}
          variant="body1"
          style={styles.title}
        >
          — étape d'arrivée :
        </Typography>
        <Typography
          textTransform="capitalize"
          variant="body1"
          style={styles.info}
        >
          {selectedTripStep?.arrival?.element?.description}
        </Typography>
        <Typography
          textTransform="capitalize"
          sx={{ mt: 1 }}
          variant="body1"
          style={styles.title}
        >
          — mode de transport :
        </Typography>
        <Typography
          textTransform="capitalize"
          variant="body1"
          style={styles.info}
        >
          {selectedTripStep?.trip?.transport_mode?.name}
        </Typography>
        {isEditable && (
          <>
            <Box sx={{ my: 2 }}>
              <Divider orientation="horizontal" flexItem />
            </Box>
            <Typography variant="h6" sx={{ mb: 1 }}>
              Documents
            </Typography>
            <DocumentList elementId={selectedTripStep?.trip?.element?.id} />
          </>
        )}
      </Box>
    </>
    //   <Typography variant="h4">Details du trajet {selectedTripStep?.id}</Typography>
    //   <Typography variant="subtitle1"></Typography>
    //   <Typography variant="subtitle1"></Typography>
    //   <Typography style={styles.title}>— Etape de départ :</Typography>
    //   {/* etape du trajet */}
    //   <Typography style={styles.title}>— Etape d'arrivée :</Typography>
    //   {/* etape du trajet - 1 */}
    //   <Typography style={styles.title}>— Mode de transport :</Typography>
    //   {selectedTripStep?.transport_mode &&
    //     <Typography variant="body1" style={styles.info} textTransform="capitalize">{selectedTripStep?.transport_mode?.name}</Typography>
    //   }
    //   <Typography variant="h6">Documents</Typography>
    //   <DocumentList elementId={selectedTripStep?.element?.id} />
    // </>
  );
};

const styles = {
  title: { fontWeight: "bold" },
  info: { marginLeft: 20 },
};
