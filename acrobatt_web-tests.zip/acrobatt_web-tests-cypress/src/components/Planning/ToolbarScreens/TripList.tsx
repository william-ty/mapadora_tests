import { Box, Typography } from "@mui/material";
import React from "react";
import { TripGroup } from "../TripGroup";

export const TripList = () => {
  return (
    <>
      <Box sx={{ backgroundColor: "accent.lightest", padding: 1, mb: 1, borderRadius: "4px"}} >
        <Typography textTransform="uppercase" color="accent.darker" ml={1} fontWeight="medium" variant="h6">Liste des trajets</Typography>
      </Box>
      <TripGroup />
    </>
  );
};
