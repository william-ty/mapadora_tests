const AppController = require("./app_controller");

class TravelTagController extends AppController {
  constructor(model) {
    super(model);
  }
}

module.exports = TravelTagController;
