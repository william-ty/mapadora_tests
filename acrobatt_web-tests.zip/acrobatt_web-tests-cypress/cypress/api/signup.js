const apiUrl = Cypress.env("baseApiUrl");


export const signup = async (user) => {
  let token = "";
    const idUser = 0

  return cy.request("POST", apiUrl + "traveler/signup", user)
};


export const deleteAccount = (idUser) => {
    cy.request("DELETE", apiUrl + "traveler/" + idUser);
}
