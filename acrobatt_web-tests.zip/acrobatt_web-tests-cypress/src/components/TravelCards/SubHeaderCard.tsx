import { Travel } from "../../model/Travel";

import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import PinDropIcon from "@mui/icons-material/PinDrop";

import RatingStars from "../PublicTravels/Rating";
import { Container } from "@mui/material";
import { Step } from "../../model/Step";
import { useEffect, useState } from "react";

type CardSubHeaderProps = {
  travel: Travel;
  listOfSteps:Step[] | undefined;
};


export const calculateDuration = (listOfSteps:Step[]) => {
  let duration = 0;
   listOfSteps.forEach((step: Step) => (duration += step.duration));
  return duration;
}


export const CardSubHeader = (props: CardSubHeaderProps) => {
  const [travelDuration, setTravelDuration] = useState<number>(1);
  const [stepNumber, setStepNumber] = useState<number>(1);
  const [stepList, setStepList] = useState<Step[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true)
 

  useEffect(() => {
        if (props.listOfSteps) {
          setStepList(props.listOfSteps);
          setStepNumber(props.listOfSteps.length);
          setTravelDuration(calculateDuration(props.listOfSteps));
        } else {
          setTravelDuration(1);
        }
        setIsLoading(false)
      },[props.listOfSteps])
      

  return (
    <>
    {!isLoading ?
      <Container>
       
      <Stack direction="row" spacing={3}>
        <Box sx={{ display: "flex" }}>
          <AccessTimeIcon sx={{ marginRight: 1 }} />
          {travelDuration > 0 ? travelDuration + " jours" : "1 jour"}
        </Box>
        <Box sx={{ display: "flex" }}>
          <PinDropIcon sx={{ marginRight: 1 }} />
          {stepNumber > 0 ? stepNumber + " étapes" : "1 étape"}
        </Box>
      </Stack>
      {props.travel.is_public ? (
        <Stack>
          <Box sx={{ mt: "20px" }}>
            <RatingStars />
          </Box>
        </Stack>
      ) : null}
    </Container> : <p>LOADING...</p>}
    </>
  );
};
