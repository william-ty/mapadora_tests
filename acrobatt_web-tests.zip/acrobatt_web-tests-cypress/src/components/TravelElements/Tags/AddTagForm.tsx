import React from "react";
import frLocale from 'date-fns/locale/fr';
import { Button, FormControl, TextField, Box, Typography } from "@mui/material";
import { AddTag } from "./TagListItem";
import { EditTag } from "./EditTag";

interface AddTagFormProps {
  addTag: AddTag;
  newTagName: string;
  handleNameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: React.MouseEventHandler<HTMLButtonElement> | undefined;
}


export const AddTagForm: React.FC<AddTagFormProps> = ({ addTag, newTagName, handleNameChange, handleSubmit }) => {


  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "row" }}>
        <EditTag
          newTagName={newTagName}
          handleNameChange={handleNameChange}
        />
        <Button sx={{ ml: 2, height: "3.4rem" }} variant='contained' type="submit" onClick={handleSubmit}>
          Ajouter
        </Button>
      </Box>
    </>
  );
};