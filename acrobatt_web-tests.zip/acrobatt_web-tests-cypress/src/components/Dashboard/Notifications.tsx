import { Container, Box, Typography } from "@mui/material";
import api from "api/api";
import { Participant } from "../../model/Participant";

import { useMutation, useQuery, useQueryClient } from "react-query";
import { useParams } from "react-router-dom";
import { useAuth } from "provider/AuthProvider";
import { url_prefix } from "api/util";
import {
  EnumPublicPrivate,
  TravelCards,
} from "components/TravelCards/TravelCards";
import { Travel } from "model/Travel";
import { useEffect, useState } from "react";

export const Notifications = () => {
  const listOfInvitationsTravel = [] as Travel[];

  const { user } = useAuth();

  const {
    isLoading: invitationsIsLoading,
    isError: invitationsIsError,
    data: invitations,
    error: invitationsError,
  } = useQuery("invitations", async () => {
    if (user) {
      return api.get({
        route: `traveler/${user.id}/invitations`,
      });
    } else {
      return [];
    }
  });
  let idParticipant = 0;
  if (invitations && invitations !== null && invitations !== undefined) {
    invitations.map((invitations: Invitations) => {
      listOfInvitationsTravel.push(invitations.participant_travel);
    });
    idParticipant = invitations.length > 0 ? invitations[0].id_participant : 0;
  }

  return (
    <Container>
      <Box>
        <Typography variant="h5">
          Invitations à rejoindre un voyage :
        </Typography>
        {!invitationsIsLoading &&
        invitations &&
        listOfInvitationsTravel.length > 0 ? (
          <Box>
            <TravelCards
              listOfTravels={listOfInvitationsTravel}
              typeOfComponent={EnumPublicPrivate.DealWithInvitations}
              idParticipant={idParticipant}
            />
          </Box>
        ) : (
          <Typography>Vous n'avez pas de nouvelle invitation.</Typography>
        )}
      </Box>
    </Container>
  );
};

type Invitations = {
  id_travel: number;
  id_participant: number;
  participant_travel: Travel;
};
