import { Link } from "react-router-dom";
import { useState } from "react";

import ModeOfTravelIcon from "@mui/icons-material/ModeOfTravel";
import { Typography, Container, Box, Button } from "@mui/material";

import { EnumPublicPrivate } from "../TravelCards/TravelCards";
import { Travel } from "../../model/Travel";
import { Loading } from "../../utility/loading/isLoading";
import { usePrivateTravelsQuery } from "../../components/TravelCards/TravelHook";
import { TravelCards } from '../TravelCards/TravelCards'

export const PrivateTravels = () => {
  const [travelList, setTravelList] = useState<Array<Travel>>([{} as Travel]);
  const [loading, setLoading] = useState<boolean>(false);

  
  const {
    isLoading: travelIsLoading,
    data: travels = [],
  } = usePrivateTravelsQuery()

  if (!travelIsLoading && travels.length>0) {
    return (
      <Container>
        <Typography variant="h5">Mes voyages</Typography>
        {loading ? (
          <Loading />
        ) : (
          <Box py={2}>
            <Box sx={{ py: 1, backcgroundColor: 'secondary.lighty' }}>
              <Typography variant="subtitle1" sx={{ pl: 2 }}>Voyages en cours</Typography>
              <TravelCards
                listOfTravels={travels.filter((travel:Travel) => !travel.end_date  )}
                typeOfComponent={EnumPublicPrivate.Private}/>
            </Box>
            <Box sx={{ py: 1, backcgroundColor: 'secondary.lighty' }}>
              <Typography variant="subtitle1" sx={{ pl: 2 }}>Voyages terminés</Typography>
              <TravelCards
                listOfTravels={travelList.filter((travel) => travel.end_date)}
                typeOfComponent={EnumPublicPrivate.Private}
              />
            </Box>
          </Box>
        )}
      </Container>
    );
  } else {
    return (
      <>
        <Typography>Vous n'avez pas de voyages</Typography>
        <Button
          to={"/dashboard/newTravel"}
          component={Link}
          variant="outlined"
          sx={{ width: "50%", mt: "30px" }}
          endIcon={<ModeOfTravelIcon />}
        >
          Créer un voyage
        </Button>
      </>
    );
  }
};
