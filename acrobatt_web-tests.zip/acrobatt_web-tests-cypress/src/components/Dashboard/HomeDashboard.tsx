import {
  Container,
  Grid,
  Box,
  Typography,
  SvgIconTypeMap,
  Button,
} from "@mui/material";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import TravelExploreIcon from "@mui/icons-material/TravelExplore";
import ModeOfTravelIcon from "@mui/icons-material/ModeOfTravel";
import LogoutIcon from "@mui/icons-material/Logout";
import { Link } from "react-router-dom";
import { useAuth } from "../../provider/AuthProvider";
import { useNavigate } from "react-router-dom";
export type IconCardsProps = {
  iconComponent: any;
  textComponent: string;
};

const IconCard = (props: IconCardsProps) => {
  return (
    <Box
      sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
    >
      <Box sx={{ width: "40%" }}>{props.iconComponent}</Box>
      <Typography>{props.textComponent}</Typography>
    </Box>
  );
};

export const HomeDashboard = () => {
  const navigate = useNavigate();

  const { signout } = useAuth();

  const logoutTraveler = () => {
    signout();
  };

  return (
    <Container>
      <Typography variant="h5" py={4}>
        Que souhaitez-vous faire ?
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <Button
            color={"secondary"}
            component={Link}
            to="/dashboard/informations"
            variant="contained"
            sx={{
              textDecoration: "none",
              width: "100%",
              justifyContent: "space-between",
              display: "flex",
              pl: 1,
              pr: 3,
            }}
          >
            <ManageAccountsIcon sx={{ fontSize: "50px" }} />
            <Typography variant="subtitle1">Modifier mes infos</Typography>
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button
            color={"secondary"}
            component={Link}
            to="/dashboard/newTravel"
            variant="contained"
            sx={{
              textDecoration: "none",
              width: "100%",
              justifyContent: "space-between",
              display: "flex",
              pl: 1,
              pr: 3,
            }}
          >
            <ModeOfTravelIcon sx={{ fontSize: "50px" }} />
            <Typography variant="subtitle1">Créer un voyage</Typography>
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button
            color={"secondary"}
            component={Link}
            to="/dashboard/travel"
            variant="contained"
            sx={{
              textDecoration: "none",
              width: "100%",
              justifyContent: "space-between",
              display: "flex",
              pl: 1,
              pr: 3,
            }}
          >
            <TravelExploreIcon sx={{ fontSize: "50px" }} />
            <Typography variant="subtitle1">Consulter mes voyages</Typography>
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button
            color={"secondary"}
            component={Link}
            to="/logout"
            variant="contained"
            sx={{
              textDecoration: "none",
              width: "100%",
              justifyContent: "space-between",
              display: "flex",
              pl: 1,
              pr: 3,
            }}
          >
            <LogoutIcon sx={{ fontSize: "50px" }} />
            <Typography variant="subtitle1">Me déconnecter</Typography>
          </Button>
        </Grid>
      </Grid>
    </Container>
  );
};
