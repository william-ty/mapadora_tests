/* eslint-disable no-undef */
/// <reference types="cypress" />
import {signup,deleteAccount} from '../api/signup'
import {signin} from '../api/signin'
import {ParticipantPage} from '../page_objects/ParticipantPage'
import {ladyLovelaceCredentials} from '../factories/Credentials'
import {Participant} from '../../src/model/Participant'
import { HomePage } from '../page_objects/HomePage';
import {createLadyLovelace} from '../factories/Users'
import "cypress-localstorage-commands"


before(() => {
    cy.loginJohnDoe();
    cy.saveLocalStorage();
  });

  beforeEach(() => {
    cy.restoreLocalStorage();
  });
describe("Add a participant to a travel", () => {
    const participantPage = new ParticipantPage();
    const homePage = new HomePage()
    const credentials = ladyLovelaceCredentials()
    
    it("Ajouter un participant au voyage 1 sans email", () => {
        const participant= new Participant({
            email:"hubert@reeves.galaxy",
            name:"Hubert Reeves"
        }) 
        participantPage.navigateTo(1);
        participantPage.addParticipantWithoutEmail(participant);
        participantPage.deleteParticipant(2)
    })

    it("Ajouter un participant qui n'a pas encore de compte", () => {
        const participant= new Participant({
            email:credentials.email,
            name:"Lady Lovelace"
        }) 
        participantPage.navigateTo(1);
        participantPage.addParticipantWithEmail(participant);
        homePage.logout()     
        signup(createLadyLovelace())
        signin(credentials)
        cy.get("[data-cy=notificationBadge]").should('contain',"1");
        cy.get("[data-cy=notifiactionsButton]").click();
        cy.url().should('contain','notifications')
        cy.get("[data-cy=travelCards]").should("contain.text","Voyage au bout du monde");
        cy.get("[data-cy=acceptInvitationButton]").click()
        cy.url().should('contain',"travel")
        homePage.logout();
        cy.loginJohnDoe();
        participantPage.navigateTo(1);
        participantPage.checkParticipantAcceptedListContent(credentials.email)
        homePage.logout();
        signin(credentials);
        
    
        
    })
})