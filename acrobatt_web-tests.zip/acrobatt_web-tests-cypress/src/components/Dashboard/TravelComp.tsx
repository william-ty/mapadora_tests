import {
  Box,
  Button,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  TextField,
} from "@mui/material";
import { useEffect, useState } from "react";
import { Travel } from "../../model/Travel";
import api from "../../api/api";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import frLocale from "date-fns/locale/fr";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";

type NewTravelProps = {
  travel: Travel | undefined;
  onSubmitAction: any;
};

export const TravelComp = (props: NewTravelProps) => {
  const [travel, setTravel] = useState<Travel>({
    name: "",
    duration: 0,
    start_date: "",
    end_date: "",
    stepsNumber: 0,
    is_public: false,
    is_album_public: false,
    path_uid: "",
    commentary: "",
    path: "",
    id_traveltag: 0,
    Travel_Traveler: {},
  });

  type TravelTag = {
    name: string;
    id: number;
  };

  const [idTag, setIdTag] = useState<number>();
  const [tagName, setTagName] = useState<string>("Tag");
  const [listTag, setListTag] = useState<Array<TravelTag>>([]);

  const [idPermission, setIdPermission] = useState<number>(1);
  const [travelName, setTravelName] = useState<string>("");
  const [travelCommentary, setTravelCommentary] = useState<string>("");

  const [travelDate, setTravelDate] = useState<Date | null>(null);

  useEffect(() => {
    if (props.travel) {
      setTravel(props.travel);
      setTravelName(props.travel.name);
      setTravelCommentary(props.travel.commentary);
      setIdTag(props.travel.id_traveltag);
      setIdPermission(props.travel.Travel_Traveler.id_permission);
    }

    getListTags().then((list) => {
      setListTag(list);
    });
  }, [props.travel]);

  const handleChangeName = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTravelName(event.target.value);
  };

  const handleChangeCommentary = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setTravelCommentary(event.target.value);
  };

  const handleChangeTag = (event: SelectChangeEvent) => {
    setIdTag(parseInt(event.target.value));
    setTagName(
      listTag.filter(
        (tag: TravelTag) => tag.id === parseInt(event.target.value)
      )[0].name
    );
    console.log(tagName);
  };

  const handleDateChange = (
    date: Date | null,
    keyboardInputValue?: string | undefined
  ) => {
    date && setTravelDate(date);
  };

  const getListTags = () => {
    return api.get({ route: "traveltag", hasToken: true });
  };

  const onSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    const travelToSave = {
      commentary: travelCommentary,
      name: travelName,
      is_public: false,
      start_date: travelDate && travelDate.toISOString(),
      end_date: null,
      id_traveltag: idTag ? idTag : null,
    };
    props.onSubmitAction(event, travelToSave);
  };

  // const ITEM_HEIGHT = 48;
  // const ITEM_PADDING_TOP = 8;

  // const MenuProps = {
  //   PaperProps: {
  //     style: {
  //       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
  //       width: 250,
  //     },
  //   },
  // };

  return (
    <>
      <Box component="form" onSubmit={onSubmit} sx={{ width: "100%", mt: 1 }}>
        <TextField
          fullWidth
          margin="normal"
          required
          id="name"
          name="name"
          label="Nom du voyage"
          value={travelName}
          onChange={handleChangeName}
          autoFocus
        />
        <TextField
          fullWidth
          margin="normal"
          required
          name="commentary"
          label="Description"
          value={travelCommentary}
          type="text"
          id="commentary"
          onChange={handleChangeCommentary}
        />
        <LocalizationProvider
          dateAdapter={AdapterDateFns}
          adapterLocale={frLocale}
        >
          <DatePicker
            mask={"__/__/____"}
            label="Date"
            value={travelDate}
            onChange={handleDateChange}
            renderInput={(params) => <TextField {...params} />}
          />
        </LocalizationProvider>
        <InputLabel id="traveltags">Tag</InputLabel>
        <Select
          sx={{ width: "auto" }}
          value={idTag?.toString()}
          onChange={handleChangeTag}
          label="Tag"
          id="tagInput"
          labelId="traveltags"
        >
          {listTag.map((tag: any) => {
            return (
              <MenuItem key={tag.id} value={tag.id}>
                {tag.name}
              </MenuItem>
            );
          })}
        </Select>

        {!travel.id || idPermission === 2 ? (
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Envoyer
          </Button>
        ) : null}
      </Box>
    </>
  );
};
