import { HashLink } from "react-router-hash-link";

import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import { createTheme } from "@mui/material/styles";
import { Typography } from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

import {
  EnumPublicPrivate,
  TravelCards
} from "../components/TravelCards/TravelCards";
import { TitleCard } from "../components/Home/TitleCard";
import { Footer } from "../components/Footer";
import { travelsFactory } from "../components/PublicTravels/factories/travelsFactory";
import {
  ImgTextComponent,
  Position,
} from "../components/Home/ImgTextComponent";

import { homeContent } from "../contents/homeContent";
import { useQuery, useQueryClient } from "react-query";
import { Travel } from "model/Travel";
import { useParams } from "react-router";
import api from "api/api";
import { usePublicTravelsQuery } from "../components/TravelCards/TravelHook";

export const ViewHomePublicTravels = () => {
  const { idTravel } = useParams();
  const queryClient = useQueryClient();

  const {
    isLoading: publicTravelsIsLoading,
    isError: publicTravelsIsError,
    data: publicTravels,
  } = usePublicTravelsQuery()

  return (
    <>
      <CssBaseline />

      <main>
        <Box
          sx={{
            bgcolor: "background.paper",
            width: "100%",
          }}
        >
          <Container
            sx={{
              minWidth: "100%",
              height: "90vh",
              pt: 4,
              pb: 4,
              borderRadius: 0,
              backgroundColor: "primary.lighter",
            }}
          >
            <TitleCard
              title=""
              subtitle="🚀Où souhaitez-vous aller ?"
              image="require('../../../img/static/logo.png)'"
            />
          </Container>
          <Box
            sx={{
              backgroundColor: "secondary.lighter",
            }}
          >
            <Container
              sx={{
                maxWidth: "80%",
                pt: "4rem",
                backgroundColor: "secondary.lighter",
              }}
            >
              <ImgTextComponent
                title={homeContent.box1.title}
                imagePath={homeContent.box1.image}
                text={homeContent.box1.text}
                imgPosition={Position.Left}
              />
              <ImgTextComponent
                title={homeContent.box2.title}
                imagePath={homeContent.box2.image}
                text={homeContent.box2.text}
                imgPosition={Position.Right}
              />
              <ImgTextComponent
                title={homeContent.box3.title}
                imagePath={homeContent.box3.image}
                text={homeContent.box3.text}
                imgPosition={Position.Left}
              />
              <ImgTextComponent
                title={homeContent.box4.title}
                imagePath={homeContent.box4.image}
                text={homeContent.box4.text}
                imgPosition={Position.Right}
              />
              <ImgTextComponent
                title={homeContent.box5.title}
                imagePath={homeContent.box5.image}
                text={homeContent.box5.text}
                imgPosition={Position.Left}
              />
            </Container>
          </Box>
        </Box>
        <Box
          sx={{
            bgcolor: "background.paper",
            pt: 10,
            pb: 10,
            width: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            // backgroundColor: "accent.light"
          }}
        >
          <img
            src={require("../img/static/content/home/car.png")}
            style={{ height: "30vh" }}
          />
          <HashLink to="#publicTravels">
            <KeyboardArrowDownIcon
              sx={{ fontSize: "250px", mb: 1, color: "secondary.main" }}
            />
          </HashLink>

          <Typography variant="h3" sx={{ width: "80%", textAlign: "center" }}>
            💡 TROUVEZ L'INSPIRATION
          </Typography>
        </Box>
        {!publicTravelsIsLoading ?
        <Box id="publicTravels">
          <TravelCards
            listOfTravels={publicTravels ? publicTravels : travelsFactory}
            typeOfComponent={EnumPublicPrivate.Public}
          />
        </Box> : <Typography>LOADING...</Typography> }
      </main>
      <Footer />
    </>
  );
};
