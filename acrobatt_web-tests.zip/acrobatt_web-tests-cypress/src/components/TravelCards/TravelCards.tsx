import { useEffect, useState } from "react";

import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { CircularProgress } from "@mui/material";

import UnitTravelCards from "./UnitTravelCard";
import { useAuth } from "../../provider/AuthProvider";
import { useNotificationQuery } from "../Dashboard/NotificationHook";
import { Travel } from "../../model/Travel";
import { Step } from "../../model/Step";
import api from '../../api/api'

export enum EnumPublicPrivate {
  Public,
  Private,
  DealWithInvitations,
}

type PublicTravelsProps = {
  typeOfComponent: any;
  listOfTravels: Array<Travel>;
  idParticipant?: number;
};

const associateSteps = async (listOfTravels: Travel[]) => {
  let newListOfTravel: Travel[] = [];
  await Promise.all(
    listOfTravels.map((travel: Travel) =>
      api
        .get({ route: Step.routeName, idTravel: travel.id })
        .then((steps: Step[]) => {
          travel.listOfSteps = steps;
          newListOfTravel.push(travel);
        })
    )
  );
  return newListOfTravel;
};

export const TravelCards = (props: PublicTravelsProps) => {
  const { user } = useAuth();
  const { refetch: refetchInvitation } = useNotificationQuery("invitations");
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [listOfTravels, setListOfTravels] = useState<Travel[]>([]);

  useEffect(() => {
    associateSteps(props.listOfTravels).then((list: Travel[]) => {
      setListOfTravels([...list]);
      setIsLoading(false);
    });
  }, [props.listOfTravels]);

  if (!isLoading && listOfTravels && listOfTravels.length > 0) {
    return (
      <Container sx={{ py: 1 }} maxWidth="xl">
        <Grid data-cy="travelCards" container spacing={5}>
          {listOfTravels.map((travel: Travel, key) => {
            return (
              <Grid item key={key} xs={12} sm={6} md={4}>
                {travel.listOfSteps ? (
                  <UnitTravelCards
                    travel={travel}
                    idParticipant={props.idParticipant}
                    typeOfComponent={props.typeOfComponent}
                    refetchInvitation={refetchInvitation}
                    user={user}
                  />
                ) : (
                  <CircularProgress />
                )}
              </Grid>
            );
          })}
        </Grid>
      </Container>
    );
  } else if (isLoading) {
    return (
      <Container>
        <Typography>LOADING...</Typography>
      </Container>
    );
  } else {
    return (
      <Container>
        <Typography>Oups, il n'y a rien à afficher...</Typography>
      </Container>
    );
  }
};
