import * as React from "react";
import { useState } from "react";

import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme } from "@mui/material/styles";

import { useAuth } from "../../provider/AuthProvider";
import { Credentials } from "../../model/Credentials";

export const SignIn = () => {
  const { signin } = useAuth();

  const theme = createTheme();

  const [credentials, setCredentials] = useState<Credentials>({
    email: "",
    password: "",
  });

  const [error, setError] = useState(false);

  const onChange = ({
    target: { name, value },
  }: React.ChangeEvent<HTMLInputElement>) => {
    setCredentials({ ...credentials, [name]: value });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    if (event) {
      event.preventDefault();
    }
    signin(credentials).catch(() => setError(true));
  };

  return (
    <Container component="main" maxWidth="xs" style={{ height: "90vh" }}>
      <CssBaseline />
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
          <LockOutlinedIcon />
        </Avatar>

        <Typography component="h1" variant="h5" data-cy="signinText">
          Connexion
        </Typography>

        <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            label="Adresse mail"
            name="email"
            value={credentials.email}
            onChange={onChange}
            autoComplete="email"
            autoFocus
            data-cy="inputLogin"
          />
          {error ? (
            <Typography color="error">Vérifier le mail</Typography>
          ) : (
            <></>
          )}
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Mot de passe"
            type="password"
            id="password"
            value={credentials.password}
            onChange={onChange}
            autoComplete="current-password"
            data-cy="inputPassword"
          />
          {error ? (
            <Typography color="error">Vérifier le mot de passe</Typography>
          ) : (
            <></>
          )}
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Se souvenir de moi"
            data-cy="rememberCheckBox"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
            data-cy="submitLogin"
          >
            Connexion
          </Button>
          <Grid container>
            <Grid item>
              <Link href="#" variant="body2">
                Récupérer le mot de passe
              </Link>
            </Grid>
            <Grid item sx={{ ml: "10px" }}>
              <Link href="/signup" variant="body2">
                Créer mon compte
              </Link>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Container>
  );
};
