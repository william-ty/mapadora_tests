import { Box, Button } from "@mui/material";
import Typography from "@mui/material/Typography";
import { Link } from "react-router-dom";

import { Copyright } from "./Copyright";

export const Footer = () => {
    return(
        <Box sx={{ bgcolor: "#ddd", p: 6 }} component="footer">
        {/* <Typography variant="h6" align="center" gutterBottom>
          Footer
        </Typography> */}
        <Typography
          variant="subtitle1"
          align="center"
          color="text.secondary"
          component="p"
        >
          Mapadora est une application super cool des Aventuriers Archi Perdus 😎
        </Typography>
        <Typography color="text.secondary" align="center" paragraph>
          {/* <Link color="inherit" href="/credits">Crédit photo</Link> */}
          <Button
            component={Link}
            style={{ textDecoration: "none" }}
            sx={{ color: "inherit" }}
            to="/credits"
          >Crédit photo</Button>
        </Typography>
        <Copyright />
      </Box>
    )
}