export const tagList = {
    placeTagList : ["Mer","Montagne","Ville"],
    countryTagList: ["Europe", "Asie", "Amérique", "Océanie", "Afrique"],
    typeList:["En famille", "Entre amis"]
}