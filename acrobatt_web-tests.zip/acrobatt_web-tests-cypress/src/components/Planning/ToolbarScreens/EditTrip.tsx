import react, { useEffect } from "react";
import { useState } from "react";
import {
  Button,
  Paper,
  Box,
  TextField,
  Typography,
  Select,
  InputLabel,
  MenuItem,
  SelectChangeEvent,
} from "@mui/material";
import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import { Trip } from "../../../model/Trip";
import { TransportMode } from "../../../model/TransportMode";
import { Element } from "../../../model/Element";
import { Point } from "../../../model/Point";
import { useMutation, useQuery, useQueryClient } from "react-query";
import api from "../../../api/api";
import { AnyLayer } from "mapbox-gl";
import { useMainData } from "../../../provider/MainDataProvider";
import { useData } from "../../../provider/DataProvider";

export type SelectedTrip = {
  id?: number;
  element?: Element;
  id_transportmode?: number;
};

export const EditTrip = () => {
  const { idTravel } = useParams();
  const id_travel = parseInt(idTravel!);
  const navigate = useNavigate();
  const { id } = useParams();
  const selectedId = id ? parseInt(id) : null;

  const {
    trips,
    transportmodes,
  }: { trips: Trip[]; transportmodes: TransportMode[] } = useOutletContext();
  // const [transportmode, setTransportMode] = useState('');
  const [selectedTransportMode, setSelectedTransportMode] =
    useState<TransportMode>();
  const [selectedTrip, setSelectedTrip] = useState<SelectedTrip>();
  const [tripToUpdate, setTripToUpdate] = useState<SelectedTrip>();

  useEffect(() => {
    console.log(transportmodes);
    console.log(trips);
  }, [transportmodes, trips]);

  // const onChange = (e: any) => setTextValue(e.target.value);

  useEffect(() => {
    trips.forEach((trip: Trip) => {
      trip?.id === selectedId && setSelectedTrip(trip);
      trip?.id === selectedId && setTripToUpdate(trip);
    });
    // console.log(transportmodes)
    // transportmodes.forEach((transportmode: TransportMode) => {
    //   transportmode?.id === selectedId && setSelectedTransportMode(transportmode);
    //   // transportmode?.id === selectedId && setTransportModeToUpdate(transportmode);
    // });
    // console.log(JSON.stringify(selectedTrip, null, 2))
  }, [selectedId, trips, selectedTrip]);

  const queryClient = useQueryClient();

  const updateTrip = useMutation(api.update, {
    onSuccess: (trip, { id }) => {
      queryClient.setQueryData<Trip[]>(["trips", id_travel], (trips) =>
        trips!.map((t) => (t.id === id ? trip : t))
      );
    },
  });

  // const onTextChange = (e: any) => setTextValue(e.target.value);
  const handleCancel = () => navigate(-1);

  const handleSubmit = (event: any) => {
    // event.preventDefault();

    console.log("ON SUBMIT : " + JSON.stringify(tripToUpdate, null, 2));

    // selectedTrip &&
    updateTrip.mutate({
      route: Trip.routeName,
      id: selectedId!,
      body: tripToUpdate!,
      idTravel: id_travel,
    });
    navigate(-1);
  };

  const onChangeTransportMode = ({
    target: { name, value },
  }: SelectChangeEvent<string>) => {
    setTripToUpdate({ ...tripToUpdate, [name]: value });
  };
  // const onChangeTransportMode = (event: SelectChangeEvent<string>, child: React.ReactNode) => {
  //   // setTransportMode(event.target.value);
  //   setTripToUpdate({ ...tripToUpdate, [name]: value });
  // };

  return (
    <Box>
      <Box
        sx={{
          backgroundColor: "accent.lighter",
          padding: 1,
          mb: 1,
          borderRadius: "4px",
        }}
      >
        <Typography
          textTransform="uppercase"
          color="accent.darker"
          ml={1}
          fontWeight="medium"
          variant="h6"
        >
          Modifier le mode de transport du trajet «{selectedTrip?.element?.name}
          »
        </Typography>
      </Box>
      <Box
        sx={{
          backgroundColor: "accent.lighter",
          padding: 2,
          borderRadius: "4px",
        }}
        display="flex"
        flexDirection="column"
      >
        <InputLabel id="transportmode-label">
          Selectionner un mode de transport
        </InputLabel>
        <Select
          labelId="transportmode-label"
          id="transportmode"
          // value={selectedT          autoWidthransportMode!.id!.toString()}

          label="Mode de transport"
          name="id_transportmode"
          onChange={onChangeTransportMode}
        >
          {/* <MenuItem value="">
            <em>Sélectionner une étape</em>
          </MenuItem> */}
          {transportmodes.map((transportmode) => (
            <MenuItem value={transportmode.id}>{transportmode.name}</MenuItem>
          ))}
        </Select>
        <Box mt={2}>
          <Button
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "warning.darky",
              "&:hover": {
                backgroundColor: "warning.main",
                color: "warning.lighter",
              },
              color: "warning.lighter",
              borderColor: "warning.main",
              textAlign: "left",
              minHeight: 0,
              padding: "0.5rem",
              minWidth: "8rem",
            }}
            onClick={handleCancel}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "accent.darky",
              "&:hover": {
                backgroundColor: "accent.main",
                color: "accent.lighter",
              },
              color: "accent.lighter",
              borderColor: "accent.main",
              textAlign: "left",
              minHeight: 0,
              padding: "0.5rem",
              minWidth: "8rem",
              ml: 2,
            }}
            onClick={handleSubmit}
          >
            Valider
          </Button>
        </Box>
      </Box>
    </Box>
  );
};
