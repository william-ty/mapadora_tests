import elementFactory from "./elementFactory";
import pointFactory from './pointFactory';
import {InterestPoint} from '../../src/model/InterestPoint'



  const  createInterestPointAssociatedToStep = () => {
  
      return  new InterestPoint(  
      {
          id: 22,
          point: pointFactory.createPointWithLonLat(7.5,48.4),
          createdAt: "2022-03-20T19:34:45.475Z",
          updatedAt: "2022-03-20T19:34:45.475Z",
          element: elementFactory.createInterestPointAssociatedToStep,
      })
  
  }
  
  module.exports = {createInterestPointAssociatedToStep};