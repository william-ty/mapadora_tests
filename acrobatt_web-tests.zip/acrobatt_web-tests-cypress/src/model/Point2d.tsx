export class Point2d {
    lng: number;
    lat:number;


    constructor(lng = 0, lat = 0){
       this.lng = lng;
       this.lat = lat;
    }

}

