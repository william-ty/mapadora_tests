module.exports = Object.freeze ( {
  regular: 1,
  admin: 2,
  superadmin: 3,
});

