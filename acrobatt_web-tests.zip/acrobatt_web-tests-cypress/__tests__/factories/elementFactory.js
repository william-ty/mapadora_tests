
import {Element} from '../../src/model/Element'


 const createElement = (id) => {

  return new Element({
    id: id,
    name: "Test",
    description: "Test",
    predicted_date: "2022-03-20",
    createdAt: "2022-03-20T19:34:45.476Z",
    updatedAt: "2022-03-20T19:34:45.476Z",
  })
}


export {createElement};
