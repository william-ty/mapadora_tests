import * as React from "react";
import { Badge, ListItemButton, ListItemIcon, ListItemText, Typography, Divider } from "@mui/material";

import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import TravelExploreIcon from "@mui/icons-material/TravelExplore";
import ModeOfTravelIcon from '@mui/icons-material/ModeOfTravel';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';

import { Link } from "react-router-dom";
import { url_prefix } from "api/util";
import { useQuery, useQueryClient } from "react-query";
import { useAuth } from "provider/AuthProvider";
import { Traveler } from "model/Traveler";
import api from "api/api";
import { useNotificationQuery } from "./NotificationHook";


type ListItemProps = {
  traveler:Traveler
}

export const ListItem = (props:ListItemProps) => {

  const queryClient = useQueryClient();

  
  const {
    isLoading: invitationsIsLoading,
    isError: invitationsIsError,
    data: invitationsCount,
    error: invitationsError
  } = useNotificationQuery(props.traveler)



  return (
    <>
      <Divider flexItem />
      <Typography color="primary.dark" component={Link} style={{ textDecoration: "none" }} to="informations">
        <ListItemButton>
          <ListItemIcon sx={{ display: "flex", justifyContent: "center" }}>
            <ManageAccountsIcon />
          </ListItemIcon>
          <ListItemText primary="Mes informations" />
        </ListItemButton>
      </Typography>
      <Divider flexItem />
      <Typography color="primary.dark" component={Link} style={{ textDecoration: "none" }} to="/dashboard/travel">
        <ListItemButton>
          <ListItemIcon sx={{ display: "flex", justifyContent: "center" }}>
            <TravelExploreIcon />
          </ListItemIcon>
          <ListItemText primary="Mes voyages" />
        </ListItemButton>
      </Typography>
      <Divider flexItem />
      <Typography color="primary.dark" component={Link} style={{ textDecoration: "none" }} to="/dashboard/newTravel">
        <ListItemButton>
          <ListItemIcon sx={{ display: "flex", justifyContent: "center" }}>
            <ModeOfTravelIcon />
          </ListItemIcon>
          <ListItemText primary="Nouveau voyage" />
        </ListItemButton>
      </Typography>
      <Divider flexItem />
      <Typography color="primary.dark" component={Link} style={{ textDecoration: "none" }} to="/dashboard/notifications">
        <ListItemButton data-cy="notifiactionsButton">
          <ListItemIcon sx={{ display: "flex", justifyContent: "center" }}>
            {invitationsCount ? 
            <Badge data-cy="notificationBadge" badgeContent={invitationsCount.count} color="primary">
            <NotificationsActiveIcon color="action" />
          </Badge>
          :
          <NotificationsActiveIcon/>
            }
          
          </ListItemIcon>
          <ListItemText primary="Notifications" />
        </ListItemButton>
      </Typography>
    </>
  );
};
