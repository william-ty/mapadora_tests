import { Stack } from "@mui/material";
import { Diary as DiaryModel } from "../../model/Diary";
import { Participant as ParticipantModel } from "../../model/Participant";
import { InlineAlert } from "../../utility/alert/InlineAlert";
import DiaryCard from "./DiaryCard";

export type DiariesAlbumProps = {
  diaries: DiaryModel[] | undefined; // Must be sorted
  participants: ParticipantModel[] | undefined;
};

const DiariesAlbum = ({ diaries, participants }: DiariesAlbumProps) => {
  return (
    <Stack spacing={2}>
      {!diaries || diaries.length === 0 ? (
        <InlineAlert
          message="Aucune entrée de journal n'est associée à ce voyage."
          severity="info"
        />
      ) : (
        diaries?.map((diary, index) => {
          const participant = participants?.find(
            (participant) => participant.id_traveler === diary.id_traveler
          )?.name;

          return (
            <DiaryCard
              key={index}
              content={diary.content}
              date={new Date(diary.updatedAt)}
              participant={participant}
            />
          );
        })
      )}
    </Stack>
  );
};

export default DiariesAlbum;
