import Button from "@mui/material/Button";
import TravelExploreIcon from "@mui/icons-material/TravelExplore";
import { Link as RouterLink } from "react-router-dom";
import Typography from "@mui/material/Typography";
import { Travel } from "../../model/Travel";

type ButtonProps = {
  redirectTo: string;
};

export const PublicButtons = (props: ButtonProps) => {
  return (
    <Button variant="contained" endIcon={<TravelExploreIcon />}>
      <Typography
        sx={{ textDecoration: "none", color: "primary.darker" }}
        component={RouterLink}
        to={`${props.redirectTo}`}
        data-testid = "button-content"
      >
        Voir
      </Typography>
    </Button>
  );
};
