/// <reference types="cypress" />

export class ParticipantPage {
  navigateTo() {
    cy.visit("dashboard/informations");
    cy.get('[data-cy="informationText"]').should("be.visible");
  }

  editInformations(firstname, lastname, email) {
    cy.get("#firstname").clear().type(firstname);
    cy.get("#lastname").clear().type(lastname);
    cy.get("#email").clear().type(email);

    cy.get('[data-cy="submitButton"]').click();
    cy.url().should("include", "dashboard");

    cy.visit("dashboard/informations");
    // cy.get('#email').should('have.text', 'newemail@gmail.com')
    // cy.get('#firstname').should('have.text', 'NewFirstName')
    // cy.get('#lastname').should('have.text', 'NewLastName')
    cy.get("[data-cy=deleteAccountButton]").should("exist");
  }
}
