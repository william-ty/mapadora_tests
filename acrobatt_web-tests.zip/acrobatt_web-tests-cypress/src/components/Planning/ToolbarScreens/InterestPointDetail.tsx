import { Visibility } from "@mui/icons-material";
import {
  Button,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Typography,
  Box,
  Divider,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { useNavigate, useOutletContext } from "react-router-dom";
import { InterestPoint } from "../../../model/InterestPoint";
import { useData } from "../../../provider/DataProvider";
import { DocumentList } from "../DocumentList";
import { InterestPointsDragGroup } from "../InterestPointsDragGroup";
import { SelectedStep } from "./EditStep";
import { Step } from "../../../model/Step";
import { DraggableStepItem } from "../../MapItems/DraggableListItem";
import StyledMenu from "components/MapItems/StyledMenu";
import { useMutation, useQuery, useQueryClient } from "react-query";
import api from "../../../api/api";
import { Task } from "model/Task";
import { TaskListTag } from "model/TaskListTag";

export const InterestPointDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const {
    interestPoints,
    isEditable,
    steps,
  }: { interestPoints: InterestPoint[]; isEditable: boolean; steps: Step[] } =
    useOutletContext();
  const queryClient = useQueryClient();

  const { map } = useData();
  const { idTravel } = useParams();
  const id_travel = parseInt(idTravel!);


  const selectedId = id ? parseInt(id) : null;
  const [selectedStep, setSelectedStep] = useState<Step>();

  const [selectedInterestPoint, setSelectedInterestPoint] =
    useState<InterestPoint>();

  const [ipTasks, setIpTasks] =
    useState<Task[]>([]);

  useEffect(() => {
    interestPoints.forEach((interestPoint: InterestPoint) => {
      interestPoint?.id === selectedId &&
        setSelectedInterestPoint(interestPoint);
    });
  }, [selectedId, interestPoints]);

  useEffect(() => {
    steps.forEach((step: Step) => {
      step?.id === selectedInterestPoint?.id_step && setSelectedStep(step);
      setSelectedStep(step);
    });
    // console.log(JSON.stringify(selectedStep, null, 2));
  }, [selectedInterestPoint, steps]);


  const {
    isLoading: taskIsLoading,
    isError: taskIsError,
    data: tasks,
  } = useQuery<Task[], Error>(
    ["tasks", id_travel],
    () =>
      api.get({
        route: Task.routeName,
        idTravel: id_travel
      }),
    { structuralSharing: false }
  );

  useEffect(() => {
    // (tasks && tasks.length > 0) && tasks.forEach((task: Task) => {
    //   (task?.TaskListTags.filter(tag => tag.name === selectedInterestPoint?.element.name)) &&
    //     (ipTasks ? setIpTasks([...ipTasks, task]) : setIpTasks([task]));
    // });

    tasks?.forEach((task: Task) => {
      const result = task?.TaskListTags.filter(tag => tag.name === selectedInterestPoint?.element.name);

      if (result.length !== 0) {
        console.log(task);
        setIpTasks([...ipTasks, task])
      }
    });

    console.log("tasks")
    console.log(tasks)
    console.log("ipTasks")
    console.log(ipTasks)
  }, [tasks]);

  const deleteStep = useMutation(api.delete, {
    onSuccess: (step, { id }) => {
      queryClient.setQueryData<Step[]>(["steps", id_travel], (steps) =>
        steps!.filter((s) => s.id !== id)
      );
    },
  });

  const onLocate = (item: Step | InterestPoint) =>
    map?.current.flyTo({
      center: item.point.coordinates,
      zoom: map?.current.getZoom(),
      pitch: map?.current.getPitch(),
      bearing: map?.current.getBearing(),
    });
  const onDelete = (item: Step | InterestPoint) =>
    item?.id &&
    deleteStep.mutate({
      route: Step.routeName,
      id: item.id,
      idTravel: id_travel,
    });
  const onEdit = (itemId: number) => navigate(`${itemId}/edit`);
  const onRead = (itemId: number) => navigate(`${itemId}`);

  const onAddPois = (item: Step) => handleOpen(item);

  const [open, setOpen] = useState(false);

  const handleOpen = (item: Step) => {
    setSelectedStep(item);
    // console.log(selectedStep);
    setOpen(true);
  };

  const handleClose = () => setOpen(false);

  return (
    <>
      <Box
        sx={{
          backgroundColor: "primary.lightest",
          padding: 1,
          mb: 1,
          borderRadius: "4px",
        }}
      >
        <Typography
          textTransform="uppercase"
          color="primary.darker"
          ml={1}
          fontWeight="medium"
          variant="h6"
        >
          Details du point d'intérêt «{selectedInterestPoint?.element?.name}»
        </Typography>
      </Box>
      <Box
        sx={{
          backgroundColor: "primary.lightest",
          padding: 2,
          borderRadius: "4px",
          // textTransform: 'capitalize' 
        }}
        display="flex"
        flexDirection="column"
      >
        <Typography variant="h6" sx={{ mb: 1 }}>
          Informations
        </Typography>
        <Typography variant="body1" style={styles.title}>
          — Nom :
        </Typography>
        <Typography variant="body1" style={styles.info}>
          {selectedInterestPoint?.element?.name}
        </Typography>
        <Typography sx={{ mt: 1 }} variant="body1" style={styles.title}>
          — Description :
        </Typography>
        <Typography variant="body1" style={styles.info}>
          {selectedInterestPoint?.element?.description}
        </Typography>
        {selectedStep &&
          <>
            <Typography sx={{ mt: 1 }} variant="body1" style={styles.title}>
              — étape associée :
            </Typography>
            <Typography variant="body1" sx={{ textTransform: 'capitalize' }} style={styles.info}>
              {selectedStep?.element?.name}
            </Typography>
            <Typography sx={{ mt: 1 }} variant="body1" style={styles.title}>
              — Jour de l'étape / Durée totale de l'étape :
            </Typography>
            {selectedInterestPoint?.day ?
              <>
                <Typography variant="body1" style={styles.info}>
                  {selectedInterestPoint?.day} / {selectedStep?.duration}
                </Typography>
              </>
              :
              <Typography variant="body1" style={styles.info}>
                Pas de jour défini / {selectedStep?.duration}
              </Typography>
            }
          </>
        }
        {(ipTasks && ipTasks.length > 0) &&
          < Typography sx={{ mt: 1 }} variant="body1" style={styles.title}>
            — Tâche(s) associée(s) :
          </Typography>
        }
        {ipTasks?.map((task, key) =>
          <Typography key={key} variant="body1" style={styles.info}>
            {task.name}
          </Typography>)}
        {isEditable && (
          <>
            <Box sx={{ my: 2 }}>
              <Divider orientation="horizontal" flexItem />
            </Box>
            <Typography variant="h6" sx={{ mb: 1 }}>
              Documents
            </Typography>
            <DocumentList elementId={selectedInterestPoint?.element?.id} />
          </>
        )}
      </Box>
    </>
  );
};

const styles = {
  title: { fontWeight: "bold" },
  info: { marginLeft: 20 },
};
