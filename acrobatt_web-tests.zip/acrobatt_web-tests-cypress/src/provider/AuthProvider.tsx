import React, { useState, useEffect, createContext, useContext } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import { checkStatus, url_prefix } from "../api/util";
import { Traveler } from "../model/Traveler";

export interface AuthContextProps {
  user: Traveler | null;
  signup: (credentials: any) => Promise<void>;
  signin: (credentials: any) => Promise<void>;
  signout: () => void;
}

const AuthContext = createContext<AuthContextProps>(undefined!);

export const AuthProvider = ({ children }: any) => {
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = window.localStorage.getItem("token");

    fetch(`${url_prefix}/traveler/whoami`, {
      method: "POST",
      headers: {
        Authorization: "Bearer " + token,
      },
    })
      .then(checkStatus)
      .then((res) => res.json())
      .then((user) => {
        console.log("setUSer");
        setUser(user);
        setLoading(false);
      })
      .catch(() => {
        setUser(null);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <h4>Checking authentication...</h4>;
  }

  const signup = (credentials: any) => {
    return api
      .create({
        route: Traveler.routeName + "/signup",
        body: new Traveler(credentials),
        hasToken: false,
      })
      .then(() => {
        navigate("/signin");
      });
  };

  const signin = (credentials: any) => {
    return api
      .create({
        route: Traveler.routeName + "/signin",
        body: credentials,
        hasToken: false,
      })
      .then((data) => {
        window.localStorage.setItem("token", data.token);
        setUser(data.user);
        navigate("/dashboard");
      });
  };

  const signout = () => {
    window.localStorage.removeItem("token");
    setUser(null);
    navigate("/");
  };

  return (
    <AuthContext.Provider value={{ user, signup, signin, signout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
