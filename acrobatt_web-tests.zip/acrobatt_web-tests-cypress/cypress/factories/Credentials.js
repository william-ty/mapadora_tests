import { Credentials } from "../../src/model/Credentials"

// export const johnDoeCredentials = () => {
//     return new Credentials({
//         email:"john@doe.com",
//         password:Cypress.env('johnDoePassword')
//     })
// }

export const ladyLovelaceCredentials = () => {
    return new Credentials({
        email:"lady@lovelace.uk",
        password:"london"
    })
}