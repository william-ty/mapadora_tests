import { Box, Typography } from "@mui/material";

export const Loading = () => {
  return (
    <Box>
      <Typography>LOADING...</Typography>
    </Box>
  );
};
