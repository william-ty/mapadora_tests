import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea, CardActions, Slide } from "@mui/material";
import { HashLink } from "react-router-hash-link";
import Box from "@mui/material/Box";
import { Logo } from "../Logo/Logo";
import Grid from "@mui/material/Grid";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import SvgMapadoraLogo from "../../img/sprites/MapadoraLogo";
import SvgMapadoraLogoCropped from "../../img/sprites/MapadoraLogoCropped";
import { useAuth } from "provider/AuthProvider";

type TagListProps = {
  image: string;
  title: string;
  subtitle: string;
};

export const TitleCard = (props: TagListProps) => {
  const { user } = useAuth();

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",

        justifyContent: "center",
        flexDirection: "column",
        maxHeight: "100%",
        minWidth: "320px",
      }}
    >
      {/* <Box height="40%"> */}
      <SvgMapadoraLogoCropped />
      {/* <SvgMapadoraLogo /> */}
      {/* </Box> */}

      <Typography gutterBottom variant="h3" component="div">
        {props.title}
      </Typography>
      <Typography variant="h4" color="text.secondary">
        {props.subtitle}
      </Typography>
      <Box sx={{ mt: 3 }}>
        <Button
          component={HashLink}
          to="#publicTravels"
          sx={{ mx: 2 }}
          size="large"
          variant="contained"
        >
          S'inspirer
        </Button>
        {!user ? (
          <Button
            component={HashLink}
            to="/login"
            sx={{ mx: 2 }}
            size="large"
            variant="outlined"
          >
            Planifier
          </Button>
        ) : (
          <Button
            component={HashLink}
            to="/dashboard/travel"
            sx={{ mx: 2 }}
            size="large"
            variant="outlined"
          >
            Planifier
          </Button>
        )}
      </Box>
      <HashLink to="#publicTravels">
        <KeyboardArrowDownIcon
          sx={{
            fontSize: "100px",
            mt: 3,
            color: "secondary.main",
            transition: "all 3s",
          }}
        />
      </HashLink>
    </Box>
  );
};
