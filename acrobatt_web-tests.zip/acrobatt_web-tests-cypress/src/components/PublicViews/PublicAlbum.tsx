import { Box, Typography } from "@mui/material";
import api from "api/api";
import Album from "components/Album/Album";
import { Travel } from "model/Travel";
import React from "react";
import { useQuery } from "react-query";
import { useParams } from "react-router";

export const PublicAlbum = () => {
  const { uidTravel } = useParams();

  const {
    isLoading: isLoading,
    isError: isError,
    data: travelData,
  } = useQuery<{ is_album_public: boolean }>(
    ["album", "travel", uidTravel],
    () => {
      return api.get({
        route: `travel/getAlbumStatus/${uidTravel}`,
        hasToken: false,
      });
    }
  );

  return (
    <>
      {travelData && travelData.is_album_public ? (
        <Album
          photoRoute={`view/${uidTravel}/photo`}
          diaryRoute={`view/${uidTravel}/diary`}
          positionRoute={`view/${uidTravel}/position`}
        />
      ) : (
        <Box style={{ display: "flex", height: "92vh", alignItems: "center" }}>
          <Typography
            sx={{
              width: "100%",
              textAlign: "center",
              alignSelf: "center",
            }}
            variant="h4"
            color="error"
          >
            Cet album de voyage est privé
          </Typography>
        </Box>
      )}
    </>
  );
};
