import {createPointWithLonLat} from '../factories/pointFactory'
import {createElement} from '../factories/elementFactory'
import {createTrip} from '../factories/tripFactory'
import {Step} from "../../src/model/Step"

 const createStepWithDurationAndOrder = (duration, order) => {

    return new Step(  
    {
        id: 22,
        point: createPointWithLonLat(7.831568775596878,48.660642473159584),
        createdAt: "2022-03-20T19:34:45.475Z",
        updatedAt: "2022-03-20T19:34:45.475Z",
        duration: duration,
        order: order,
        element: createElement(),
        trip:createTrip()
    })

}
module.exports =  {createStepWithDurationAndOrder};