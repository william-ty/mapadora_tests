import { Button, Divider, Icon, Stack, Typography } from "@mui/material";
import { useNavigate, useOutletContext } from "react-router-dom";
import { Step } from "../../../model/Step";

export const Welcome = () => {

  const {
    steps
  }: {
    steps: Step[];
  } = useOutletContext();
  const navigate = useNavigate();

  return (
    <>
      {
      // 1 + 1 === 2 ?
        <Stack
          direction="column"
          divider={<Divider orientation="horizontal" flexItem />}
          // spacing={4}
          // pt={10}
          display="flex"
          justifyContent="space-evenly"
          alignItems="center"
          height="100%"
        >
          <Button
            color={"secondary"}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "secondary.darky",
              "&:hover": {
                backgroundColor: "secondary.main",
                color: "secondary.lighter",
              },
              color: "secondary.lighter",
              borderColor: "secondary.main",
              width: "100%",
              height: "30%",
              mb: 1
            }}
            onClick={() => {
              navigate("steps");
            }}
          >
            <Icon fontSize="large">location_on</Icon>
            <Typography ml={1}>étapes</Typography>
          </Button>
          <Button
            color={"primary"}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "primary.darky",
              "&:hover": {
                backgroundColor: "primary.main",
                color: "primary.lighter",
              },
              color: "primary.lighter",
              borderColor: "primary.main",
              width: "100%",
              height: "30%",
              my: 1
            }}
            onClick={() => {
              navigate("interestpoints");
            }}
          >
            <Icon fontSize="large">location_on</Icon>
            <Typography ml={1}>points d'intérêt</Typography>
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "gray.darky",
              "&:hover": {
                backgroundColor: "gray.main",
                color: "gray.lighter",
              },
              color: "gray.lighter",
              borderColor: "gray.main",
              width: "100%",
              height: "30%",
              mt: 1
            }}
            onClick={() => {
              navigate("trips");
            }}
          >
            <Icon fontSize="large">moving</Icon>
            <Typography ml={1}>trajets</Typography>
          </Button>
        </Stack>
        // :
        // <Stack
        //   direction="column"
        //   divider={<Divider orientation="horizontal" flexItem />}
        //   spacing={4}
        //   pt={10}
        // >
        //   <Typography
        //     variant="h5"
        //     component="h2"
        //     sx={{ color: "primary", textAlign: "center", textJustify: "justify" }}
        //   >
        //     Bienvenue sur l'outil de plannification de voyage ! <br />
        //     🚗🚅🛸🚀🚲
        //     <br />
        //   </Typography>
        //   <Typography
        //     variant="subtitle2"
        //     component="h4"
        //     sx={{ textAlign: "center", textJustify: "justify" }}
        //   >
        //     Veuillez placer une étape pour commencer 😎
        //   </Typography>
        // </Stack>
      }
    </>
  );
};
