import {
  Container,
  Box,
  Typography,
  Button,
  TextField,
  IconButton,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  FormControl,
  Input,
} from "@mui/material";
import api from "api/api";
import { Participant } from "../../model/Participant";

import { useMutation, useQuery, useQueryClient } from "react-query";
import { useParams } from "react-router-dom";

import GroupAddIcon from "@mui/icons-material/GroupAdd";
import SendIcon from "@mui/icons-material/Send";
import GroupRemoveIcon from "@mui/icons-material/GroupRemove";

import { useState } from "react";
import { useAuth } from "provider/AuthProvider";
import { useForm } from "react-hook-form";

const Participants = () => {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [showInputField, setShowInputField] = useState(false);
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const params = useParams();
  const idTravel = params.idTravel ? parseInt(params.idTravel) : 0;
  const {
    handleSubmit,
    register,
    formState: { errors, isValid },
  } = useForm();
  const {
    isLoading: participantsIsLoading,
    data: participants,
    error: participantsError,
  } = useQuery(["participants", idTravel], async () => {
    return api.get({
      route: Participant.routeName,
      hasToken: true,
      idTravel: idTravel,
    });
  });

  const {
    isLoading: isLoading,
    isError: isError,
    data: travelData,
  } = useQuery("travelData", () => {
    return api.get({ route: `travel/${idTravel}`, hasToken: true });
  });

  const {
    isLoading: isAdminLoading,
    isError: isAdminError,
    data: admin,
  } = useQuery("admin", () => {
    return api.get({ route: `admin`, hasToken: true, idTravel: idTravel });
  });

  const participantsAccepted = participants
    ? participants.filter((part: Participant) => {
        return (
          (part.id_traveler !== null || part.email === null) &&
          part.id_traveler !== user?.id
        );
      })
    : [];

  const participantsWaiting = participants
    ? participants.filter((part: Participant) => {
        return part.id_traveler === null && part.email !== null;
      })
    : [];

  const showInput = () => {
    setShowInputField(!showInputField);
  };
  const handleChangeName = (event: any) => {
    if (createParticipantMutation.isError) {
      createParticipantMutation.reset();
    }
    setName(event.target.value);
  };
  const handleChangeEmail = (event: any) => {
    if (createParticipantMutation.isError) {
      createParticipantMutation.reset();
    }
    setEmail(event.target.value);
  };

  const createParticipant = (participant: any) => {
    return api.create({
      route: Participant.routeName,
      body: participant,
      hasToken: true,
      idTravel: idTravel,
    });
  };

  const deleteParticipant = (participant: any) => {
    return api.delete({
      route: Participant.routeName,
      id: participant.id_participant,
      hasToken: true,
      idTravel: idTravel,
    });
  };

  const createParticipantMutation = useMutation(createParticipant, {
    onSuccess: (participant) => {
      queryClient.setQueryData(
        ["participants", idTravel],
        (participants: any) => [...participants, participant]
      );
    },
  });

  const deleteParticipantMutation = useMutation(deleteParticipant, {
    onSuccess: (participant) => {
      console.log(participant);
      queryClient.setQueryData(
        ["participants", idTravel],
        (participants: any) =>
          participants.filter(
            (part: any) => part.id_participant !== participant.id
          )
      );
    },
  });

  const sendInvitation = () => {
    const participant = {
      name: name,
      email: email ? email : null,
      hasRefused: false,
      id_traveler: undefined,
    };
console.log(errors)
    if(!errors.name && !errors.email){
    createParticipantMutation.mutate(participant) 
    
    if (!createParticipantMutation.isError) {
      resetFields();
    } else {
      setEmail(participant.email ? participant.email : "");
      setName(participant.name);
    }
  }
  };

  const resetFields = (): void => {
    setEmail("");
    setName("");
  };

  return (
    <>
      {travelData && travelData.Travel_Traveler.id_permission === 2 ? (
        <Box>
          <Button
            data-cy="addParticipantButton"
            variant="contained"
            onClick={showInput}
            endIcon={<GroupAddIcon />}
          >
            <Typography data-cy="addParticipantText"
              sx={{ textDecoration: "none", color: "primary.darker" }}
            >
              Ajouter un participant
            </Typography>
          </Button>
          {showInputField ? (
            <Box sx={{ my: "20px" }}>
              <form  onSubmit={handleSubmit(sendInvitation)}>
                <TextField
                {...register("nameInput",{
                  required: true
                })}
                  label="Nom"
                  onChange={handleChangeName}
                  value={name}
                  required
                  data-cy="inputParticipantName"
                />
                {errors.name && <p>Nom requis</p>}

                <TextField
                {...register("emailInput",{
                  pattern : /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g
                  
                })}
                  label="Email"
                  onChange={handleChangeEmail}
                  value={email}
                  type="email"
                  data-cy="inputParticipantEmail"
                  sx={{ mx: "10px" }}
                />
                {errors.email && <p>Email non valide</p>}

                <Button
                  type="submit"
                  variant="contained"
                  sx={{ height: "56px" }}
                  data-cy="submitParticipant"
                  // onClick={sendInvitation}
                  endIcon={<SendIcon />}
                  disabled={name.length === 0}
                >
                  Envoyer l'invitation
                  {createParticipantMutation.isLoading ? (
                    <CircularProgress />
                  ) : null}
                </Button>
              </form>
            </Box>
          ) : null}
        </Box>
      ) : null}
      {createParticipantMutation.isError ? (
        <Typography color="error">Erreur lors de l'ajout...</Typography>
      ) : null}
      {!participantsIsLoading && !participantsError ? (
        <Container>
          <Box>
            <Typography variant="h5" sx={{ my: "10px" }}>
              Participants associés au voyage
            </Typography>
            {travelData && travelData.Travel_Traveler.id_permission === 2 ? (
              <Typography> Vous êtes administrateur du voyage </Typography>
            ) : admin ? (
              <Typography>
                {" "}
                Voyage administré par {admin.firstname} {admin.lastname} |{" "}
                {admin.email}{" "}
              </Typography>
            ) : null}

            {participantsAccepted.length > 0 ? (
              <List data-cy="participantAcceptedList">
                {participantsAccepted.map((part: Participant) => {
                  return (
                    <ListItem sx={{ width: "50%" }}>
                      <ListItemText
                        primary={
                          <Typography data-cy="participantAccepted">
                            {" "}
                            {part.name} | {part.email}{" "}
                          </Typography>
                        }
                      />

                      {travelData &&
                      travelData.Travel_Traveler.id_permission === 2 ? (
                        <IconButton
                          aria-label="delete"
                          onClick={() => deleteParticipantMutation.mutate(part)}
                        >
                          <GroupRemoveIcon />
                        </IconButton>
                      ) : null}
                    </ListItem>
                  );
                })}
              </List>
            ) : (
              <Typography>Pas de participants associés</Typography>
            )}
            <Typography variant="h5" sx={{ my: "10px" }}>
              Invitations en attente
            </Typography>
            {participantsWaiting.length > 0 ? (
              <List data-cy="participantInWaitingList">
                {participantsWaiting.map((part: Participant) => {
                  return (
                    <ListItem sx={{ width: "50%" }}>
                      <ListItemText
                        primary={
                          <Typography data-cy="participantInWaiting">
                            {" "}
                            {part.name} | {part.email}{" "}
                          </Typography>
                        }
                      />

                      {travelData &&
                      travelData.Travel_Traveler.id_permission === 2 ? (
                        <IconButton
                          aria-label="delete"
                          data-cy="deleteParticipant"
                          onClick={() => deleteParticipantMutation.mutate(part)}
                        >
                          <GroupRemoveIcon />
                        </IconButton>
                      ) : null}
                    </ListItem>
                  );
                })}
              </List>
            ) : (
              <Typography>Pas d'invitations en attente</Typography>
            )}
          </Box>
        </Container>
      ) : (
        <>"LOADING..."</>
      )}{" "}
    </>
  );
};

export default Participants;
