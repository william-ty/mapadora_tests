module.exports = {
  "projectId": "rwfg4b",
  "watchForFileChanges": false,
  "e2e": {
    "baseUrl": "http://localhost:3000"
  },
  "env": {
    "baseApiUrl": "http://localhost:8080/",
    "utilisateurPassword": "12345",
    "jeanPassword": "jean",
    "johnDoePassword": "12345"
  },
  "baseUrl": "http://localhost:3000"
}
