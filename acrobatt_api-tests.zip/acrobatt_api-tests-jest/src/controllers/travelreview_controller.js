const AppController = require("./app_controller");

class TravelReviewController extends AppController {
  constructor(model) {
    super(model);
  }
}

module.exports = TravelReviewController;
