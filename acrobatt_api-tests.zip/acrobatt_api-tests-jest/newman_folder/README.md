### Running Tests with Newman

#### For windows run the following command in this directory:
newman run https://www.getpostman.com/collections/efaee735f77861799640 -e .\localhost.postman_environment.json
#### For unix run the following command in this directory:
newman run https://www.getpostman.com/collections/efaee735f77861799640 -e /localhost.postman_environment.json
