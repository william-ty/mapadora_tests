import { Button, Typography, Grid } from "@mui/material";
import TravelExploreIcon from "@mui/icons-material/TravelExplore";
import { Link as RouterLink } from "react-router-dom";
import { Travel } from "../../model/Travel";

type ButtonProps = {
    travel:Travel
}

export const PrivateButtons = (props:ButtonProps) => {
  return (
    <Grid container spacing={1}>
        <Grid item >
      <Button variant="contained" sx={{ mr: "20px" }} data-testId="button-planif">
        <Typography
          sx={{ textDecoration: "none", color: "primary.darker" }}
          component={RouterLink}
          to={`/travel/${props.travel.id}`}
        >
          Planifier
        </Typography>
      </Button></Grid>
      <Grid item >
      <Button variant="contained" data-testId="button-edit">
        <Typography
          sx={{ textDecoration: "none", color: "primary.darker" }}
          component={RouterLink}
          to={`${props.travel.id}`}
        >
          Editer
        </Typography>
      </Button></Grid>
    </Grid>
  );
};
