const AppController = require("./app_controller");

class TaskListController extends AppController {
  constructor(model) {
    super(model);
  }
}

module.exports = TaskListController;
