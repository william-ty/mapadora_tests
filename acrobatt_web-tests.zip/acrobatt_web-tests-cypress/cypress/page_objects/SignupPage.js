/// <reference types="cypress" />


export class SignupPage {

  navigateTo() {
    cy.visit(`signup`);
    cy.get('[data-cy="signupText"]').should("be.visible");
  }

  isNotUserBar() {
    cy.get("[data-cy=userBar]").should("not.exist");
  }

  fillAndSubmit(traveler) {
    cy.get("#firstname").type(traveler.firstname);
    cy.get("#lastname").type(traveler.lastname);
    cy.get("#email").type(traveler.email);
    cy.get("#password").type(traveler.password);
    cy.get(".css-binzgt > .MuiBox-root > .MuiButton-root").click();
    cy.url().should("include", "signin");
  }
}
