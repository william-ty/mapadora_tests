import React from "react";
import { StepsDragGroup } from "../StepsDragGroup";
import { Paper, Typography, Box } from '@mui/material';

export const StepList = () => {
  return (
    <>
      <Box sx={{ backgroundColor: "secondary.lightest", padding: 1, mb: 1, borderRadius: "4px"}} >
        <Typography textTransform="uppercase" color="secondary.darker" ml={1} fontWeight="medium" variant="h6">Liste des étapes</Typography>
      </Box>
      <StepsDragGroup />
    </>
  );
};
