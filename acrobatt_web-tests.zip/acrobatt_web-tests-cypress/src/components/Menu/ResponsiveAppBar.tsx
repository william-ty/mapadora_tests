import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

import { Logo } from "../Logo/Logo";
import { useAuth } from "../../provider/AuthProvider";
import AlertDialog from "../../utility/alert/alertToUser";
import { MobileMenu } from "./MobileMenu";

import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import Container from "@mui/material/Container";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import Divider from "@mui/material/Divider";

import LogoutIcon from "@mui/icons-material/Logout";
import FaceIcon from "@mui/icons-material/Face";
import MenuIcon from "@mui/icons-material/Menu";

import SvgMapadoraLogoFlat201 from "../../img/sprites/MapadoraLogoFlat";
import { Icon } from "@mui/material";

// const pages = ["home", "travel", "planning"];

const settings = [
  <Link to="/dashboard" style={{ textDecoration: "none" }}>
    Dashboard 🏠
  </Link>,
  <Link to="/logout" style={{ textDecoration: "none" }}>
    Logout 🏠
  </Link>,
];

const ResponsiveAppBar = () => {
  const [logoutDialog, setLogOutDialog] = useState(false);

  const navigate = useNavigate();

  const { user, signout } = useAuth();

  const handleLogout = () => {
    setLogOutDialog(true);
  };

  const logoutTraveler = () => {
    setLogOutDialog(false);
    signout();
  };

  const [anchorElNav, setAnchorElNav] = useState<null | HTMLElement>(null);
  const [anchorElUser, setAnchorElUser] = useState<null | HTMLElement>(null);

  const handleDashboard = () => {
    return navigate("/dashboard");
  };

  // const handleOpenNavMenu = (event: React.MouseEvent<HTMLElement>) => {
  //   setAnchorElNav(event.currentTarget);
  // };
  // const handleOpenUserMenu = (event: React.MouseEvent<HTMLElement>) => {
  //   setAnchorElUser(event.currentTarget);
  // };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <AppBar sx={{ zIndex: "50" }} position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters sx={{ whiteSpace: "nowrap", height: "7vh" }}>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ mr: 2, display: { xs: "none", md: "flex" } }}
          >
            <Box
              component={Link}
              to="/"
              maxHeight="8vh"
              maxWidth="30vh"
              display="flex"
            >
              <SvgMapadoraLogoFlat201 height="100%" width="100%" />
            </Box>
          </Typography>

          <MobileMenu />

          <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
            <Button
              sx={{ my: 2, display: "block" }}
              key="home"
              onClick={handleCloseNavMenu}
            >
              <Typography textAlign="center">
                <Button
                  component={Link}
                  style={{ textDecoration: "none" }}
                  sx={{ color: "secondary.lightest" }}
                  to="/"
                >
                  <Icon>home</Icon>Accueil
                </Button>
              </Typography>
            </Button>

            <Button
              sx={{ my: 2, display: "block" }}
              key="planning"
              onClick={handleCloseNavMenu}
            >
              <Typography textAlign="center">
                <Button
                  component={Link}
                  style={{ textDecoration: "none" }}
                  sx={{ color: "secondary.lightest" }}
                  to={user ? "/dashboard/travel" : "/signin"}
                >
                  <Icon>fmd_good</Icon>Planifier un voyage
                </Button>
              </Typography>
            </Button>
          </Box>

          {logoutDialog ? (
            <AlertDialog
              activate={true}
              dialogTitle={"Vous allez être déconnecté.e"}
              dialogDescription={""}
              onCloseYesAction={() => logoutTraveler()}
              onCloseNoAction={() => setLogOutDialog(false)}
            />
          ) : null}

          {user ? (
            <Box
              sx={{ display: "flex", flexGrow: 0, alignItems: "center" }}
              data-cy="userBar"
            >
              {/* <Box> */}
              <Typography sx={{ mr: 1 }}>Bienvenue</Typography>
              <Typography
                fontWeight="bold"
                data-cy="userLoggedNameText"
                sx={{ mr: 2 }}
              >
                {user.firstname} {user.lastname}
              </Typography>
              <Divider orientation="vertical" flexItem />
              {/* </Box> */}
              <Box ml={1}>
                <Tooltip title="Ouvrir le panneau d'admin">
                  <IconButton sx={{ height: "80%" }} onClick={handleDashboard}>
                    <FaceIcon />
                  </IconButton>
                </Tooltip>
                <IconButton sx={{ height: "80%" }} onClick={handleLogout}>
                  <LogoutIcon />
                </IconButton>
              </Box>

              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting, idx) => (
                  <MenuItem key={idx} onClick={handleCloseUserMenu}>
                    <Typography textAlign="center">{setting}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          ) : (
            <Box display="flex" alignItems="center">
              <Button
                component={Link}
                to="/signup"
                style={{ textDecoration: "none" }}
                sx={{ color: "secondary.lightest" }}
              >
                Créer un compte
              </Button>
              <Typography sx={{ color: "secondary.lightest", mx: 1 }}>
                {" "}
                |{" "}
              </Typography>
              <Button
                component={Link}
                to="/signin"
                style={{ textDecoration: "none" }}
                sx={{
                  color: "secondary.lightest",
                  border: "2px solid",
                  borderColor: "secondary.lighter",
                }}
              >
                Se connecter
              </Button>
            </Box>
          )}
        </Toolbar>
      </Container>
    </AppBar>
  );
};
export default ResponsiveAppBar;
