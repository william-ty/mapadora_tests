import { Box, SelectChangeEvent, Typography } from "@mui/material";
import { Task } from "model/Task";
import { TaskListTag } from "model/TaskListTag";
import React from "react";
import { ToggleComplete, HandleDelete, HandleUpdate } from "./TodoListItem";
import { TodoListItem } from "./TodoListItem";

interface TodoListProps {
  todos?: Array<Task>;
  toggleComplete: ToggleComplete;
  handleDelete: HandleDelete;
  handleUpdate: HandleUpdate;
  handleClickTagToAdd: (tag: TaskListTag, selectedTask: Task) => void;
  onChangeTag: ({ target: { name, value }, }: SelectChangeEvent<string>) => void;
  tags: TaskListTag[];
  handleDeleteTagFromTask: (tag: TaskListTag, selectedTodo: Task) => void;
}

export const TodoList: React.FC<TodoListProps> = ({
  todos,
  toggleComplete,
  handleDelete,
  handleUpdate,
  onChangeTag,
  handleClickTagToAdd,
  handleDeleteTagFromTask,
  tags
}) => {

  return (
    <>
      <Box sx={{ my: 2 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: "bold", mb: 1 }}>Tâches prévues:</Typography>
        {(todos && todos.filter((todo) => !todo.is_terminated).length > 0) ? todos.filter((todo) => !todo.is_terminated).map(todo => (
          <TodoListItem
            key={todo.id}
            todo={todo}
            toggleComplete={toggleComplete}
            handleDelete={handleDelete}
            handleUpdate={handleUpdate}
            onChangeTag={onChangeTag}
            handleClickTagToAdd={handleClickTagToAdd}
            tags={tags}
            handleDeleteTagFromTask={handleDeleteTagFromTask}
          />
        )) : <Typography variant="subtitle2">Aucunes tâches pour le moment.</Typography>}
      </Box>
      <Box sx={{ my: 2 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: "bold", mb: 1 }}>Tâches terminées:</Typography>
        {(todos && todos.filter((todo) => todo.is_terminated).length > 0) ? todos.filter((todo) => todo.is_terminated).map(todo => (
          <TodoListItem
            key={todo.id}
            todo={todo}
            toggleComplete={toggleComplete}
            handleDelete={handleDelete}
            handleUpdate={handleUpdate}
            onChangeTag={onChangeTag}
            handleClickTagToAdd={handleClickTagToAdd}
            tags={tags}
            handleDeleteTagFromTask={handleDeleteTagFromTask}
          />
        )) : <Typography variant="subtitle2">Aucunes tâches pour le moment.</Typography>}
      </Box>
    </>
  );
};