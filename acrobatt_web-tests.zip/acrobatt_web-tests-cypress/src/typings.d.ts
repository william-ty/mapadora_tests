export type Item = {
  id: string;
  title: string;
};
