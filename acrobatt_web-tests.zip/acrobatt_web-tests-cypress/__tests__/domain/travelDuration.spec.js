import { createStepWithDurationAndOrder } from "../factories/stepFactory";
import { calculateDuration } from "../../src/components/TravelCards/SubHeaderCard";
// on créé trois étapes avec des durées différents
test("travelDuration returns 6", () => {
  //arrange
  const step1 = createStepWithDurationAndOrder(2, 1);
  const step2 = createStepWithDurationAndOrder(3, 2);
  const step3 = createStepWithDurationAndOrder(1, 2);
  const listOfSteps = [];
  listOfSteps.push(step1);
  listOfSteps.push(step2);
  listOfSteps.push(step3);

  //act
  const duration = calculateDuration(listOfSteps);

  //assert
  expect(duration).toEqual(6);
});
