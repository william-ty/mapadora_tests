
import * as React from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Icon from '@mui/material/Icon';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItem from '@mui/material/ListItem';
import { TaskListTag } from 'model/TaskListTag';
import { EditTag } from './EditTag';
import { Typography } from '@mui/material';

export type ToggleComplete = (selectedTag: TaskListTag) => void;
export type HandleDelete = (selectedTag: TaskListTag) => void;
export type HandleUpdate = (selectedTag: TaskListTag) => void;

export type AddTag = (newTag: TaskListTag) => void;

interface TagListItemProps {
  tag: TaskListTag;
  handleDelete: HandleDelete;
  handleUpdate: HandleUpdate;
  newTagName?: string;
  handleNameChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const TagListItem: React.FC<TagListItemProps> = ({
  tag,
  handleDelete,
  handleUpdate,
  newTagName,
  handleNameChange,
}) => {

  const [editMode, setEditMode] = React.useState<boolean>(false);

  return (
    <>
      <Box display="flex"
        sx={{ mb: 1 }}
      >
        {editMode === true ?
          <ListItem
            sx={{ backgroundColor: 'primary.lighter', p: 1.5 }}
          // key={tag}
          >
            <EditTag
              newTagName={newTagName!}
              handleNameChange={handleNameChange!}
            />

          </ListItem>
          :
          <ListItem
            sx={{ backgroundColor: 'primary.lighter' }}
            // key={tag}
          >
            <ListItemButton>
              <ListItemText sx={{ flex: 5 }} primary={`${tag.name}`} />
            </ListItemButton>
          </ListItem>
        }
        {editMode === false ?
          <>
            <Button variant='contained' sx={{ mx: 1 }} onClick={() => handleDelete(tag)}>
              <Icon>delete</Icon>
            </Button>
            <Button
              variant='contained'
              sx={{ px: 1 }}
              onClick={() => { editMode ? setEditMode(false) : setEditMode(true) }}
            >
              <Icon>edit</Icon>
            </Button>
          </>
          :
          <Button
            variant='contained'
            sx={{ px: 3.5, ml: 1 }}
            onClick={() => {
              console.log(tag)
              handleUpdate(tag);
              editMode ? setEditMode(false) : setEditMode(true);
            }}
          >
            <Typography sx={{ fontWeight: "bold" }}>Confirmer</Typography>
          </Button>
        }
      </Box>
    </>
  );
};