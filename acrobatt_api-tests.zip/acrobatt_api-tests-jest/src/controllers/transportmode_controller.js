const AppController = require("./app_controller");

class TransportModeController extends AppController {
  constructor(model) {
    super(model);
  }
}

module.exports = TransportModeController;
