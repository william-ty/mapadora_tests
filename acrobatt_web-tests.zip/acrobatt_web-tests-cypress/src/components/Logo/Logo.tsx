import { Box } from "@mui/material"
import * as Svgs from '../../img/sprites/index';

type LogoProps = {
  height: string;
};

export const Logo = (props: LogoProps) => {
  return (
    <>
      {/* <img src={require('../../img/static/logo.png')} alt="Logo" height={props.height} /> */}
      {/* <SvgMapadoraLogoFlat201 /> */}
      <Svgs.MapadoraLogoFlat height={props.height}/>
      {/* <IconClose /> */}
      {/* <SvgIconCart/> */}
    </>
  )
}