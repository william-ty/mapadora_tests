import { Container, List, ListItem, ListItemButton, ListItemText, Typography } from "@mui/material";
import { homeCredits } from "contents/creditsContent";
import { Footer } from "./Footer";

export type Credit = {
  primaryContent: string;
  secondaryContent?: string;
  link: string;
}

export type PhotoCreditSectionProps = {
  title: string;
  credits: Credit[];
};

const PhotoCreditSection = ({ title, credits }: PhotoCreditSectionProps) => {
  return (
    <>
      <Typography variant="h4">{title}</Typography>

      <List>
        {
          credits.map((credit, index) => {
            return (
              <ListItem key={index} disablePadding divider>
                <ListItemButton component="a" href={credit.link} disableGutters>
                  <ListItemText primary={credit.primaryContent} secondary={credit.secondaryContent} />
                </ListItemButton>
              </ListItem>
            );
          })
        }
      </List>
    </>
  );
};

const PhotoCredit = () => {
  return (
    <>
      <Container sx={{ py: 10 }} maxWidth="lg">
        <Typography variant="h3">Crédit photo</Typography>

        <PhotoCreditSection title="Page d'accueil" credits={homeCredits} />
      </Container>
      <Footer />
    </>
  );
};

export default PhotoCredit;
