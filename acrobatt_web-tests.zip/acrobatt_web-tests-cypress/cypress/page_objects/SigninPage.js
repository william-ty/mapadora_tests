/// <reference types="cypress" />
export class SigninPage {
  navigateTo() {
    cy.visit(`signin`);
    cy.get('[data-cy="signinText"]').should("be.visible");
  }

  isNotUserBar() {
    cy.get("[data-cy=userBar]").should("not.exist");
  }

  fillAndSubmit(credentials) {
    cy.get("#email").type(credentials.email);
    cy.get("#password").type(credentials.password);
    cy.get(".css-binzgt > .MuiBox-root > .MuiButton-root").click();
    cy.url().should("include", "dashboard");
  }
}
