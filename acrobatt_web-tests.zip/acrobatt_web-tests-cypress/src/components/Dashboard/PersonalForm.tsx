import {
  Box,
  TextField,
  Button,
  Grid,
  Link,
  Typography,
  Container,
} from "@mui/material";
import { useAuth } from "../../provider/AuthProvider";
import { useEffect, useState } from "react";
import { Traveler } from "../../model/Traveler";
import api from "../../api/api";
import { useNavigate } from "react-router-dom";
import alertToUser, { AlertProps } from "../../utility/alert/alertToUser";
import AlertDialog from "../../utility/alert/alertToUser";
import theme from "./../../theme/theme";

export const PersonalForm = () => {
  const navigate = useNavigate();
  const { user, signout } = useAuth();

  const onChange = ({
    target: { name, value },
  }: React.ChangeEvent<HTMLInputElement>) => {
    if(travelerInput)
    setTravelerInput({ ...travelerInput, [name]: value });
  };

  const [dialog, setDialog] = useState<boolean>(false);
  const [travelerInput, setTravelerInput] = useState<Traveler | undefined>(user!);

  useEffect(() => {
    setTravelerInput(user!);
    setDialog(false);
  }, [user]);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);

    const travelerUpdate = {
      firstname: data.get("firstname"),
      lastname: data.get("lastname"),
      email: data.get("email"),
    };

    Object.assign(travelerUpdate, travelerInput);
    if (travelerInput?.id) {
      api
        .update({
          route: Traveler.routeName,
          id: travelerInput.id,
          body: travelerInput,
          hasToken: true,
        })
        .then(() => navigate("/dashboard"));
    }
  };

  const deleteAccount = () => {
    user?.id !== undefined ? setDialog(true) : setDialog(false);
  };


  return (
    
    <Container>
      {travelerInput ?
      <>
      <Typography variant="h5" data-cy="informationText">Mes informations</Typography>
      {dialog ? (
        <AlertDialog
          activate={true}
          dialogTitle={"Êtes-vous sûr.e de votre coup ?"}
          dialogDescription={"Toutes vos données seront perdues :("}
          onCloseNoAction={() => setDialog(false)}
          onCloseYesAction={() =>
            user?.id
              ?  api
                  .delete({
                    route: Traveler.routeName,
                    id: user.id,
                    hasToken: true,
                  })
                  .then(() => {
                    setTravelerInput(undefined);
                    signout()
                  })
              : navigate("/")
          }
        />
      ) : null}

      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{ width: "100%", mt: 1 }}
      >
        <TextField
          fullWidth
          margin="normal"
          name="firstname"
          type="text"
          value={travelerInput.firstname}
          data-cy="firstname"
          id="firstname"
          onChange={onChange}
        />

        <TextField
          fullWidth
          margin="normal"
          name="lastname"
          type="text"
          value={travelerInput.lastname}
          id="lastname"
          data-cy="lastname"
          onChange={onChange}
        />

        <TextField
          fullWidth
          margin="normal"
          id="email"
          name="email"
          autoComplete="email"
          data-cy="email"
          value={travelerInput.email}
          autoFocus
          onChange={onChange}
        />

        <Button
          type="submit"
          data-cy="submitButton"
          fullWidth
          variant="contained"
          sx={{ mt: 3, mb: 2 }}
        >
          Enregistrer
        </Button>
        {/* TODO */}
        {/* <Grid container>
          <Grid item xs>
            <Link href="#" variant="body2">
              Forgot password?
            </Link>
          </Grid>
        </Grid> */}
      </Box>
      <Button
        variant="contained"
        data-cy="deleteAccountButton"
        onClick={deleteAccount}
        color="error"
        sx={{ mt: 3, mb: 2 }}
      >
        Supprimer mon compte
      </Button>
      </>
      : null}
    </Container> 
  );
};


