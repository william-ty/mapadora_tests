import api from "../../api/api";
import { useQuery, useQueryClient } from "react-query";


export const usePrivateTravelsQuery = ():any => {

    return useQuery("travels", () => {
        return api.get({ route: "mytravels" })}
      )
}

export const usePublicTravelsQuery = ():any => {
    return useQuery("publictravels", () => {
        return api.get({ route: "publictravels" }) 
    });
}

