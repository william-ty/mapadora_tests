import {
  Container,
  Typography,
  Button,
  Box,
  TextField,
  Grid,
  InputLabel,
  Select,
  Chip,
  MenuItem,
  OutlinedInput,
  Checkbox,
  ListItemText,
  Divider,
} from "@mui/material";

import { tagList } from "../Tags/factories/tagListFactory";

import { useMutation, useQuery, useQueryClient } from "react-query";

import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../../api/api";
import { Travel } from "../../model/Travel";
import AlertDialog from "../../utility/alert/alertToUser";
import { checkStatus } from "../../api/util";
import { url_prefix } from "../../api/util";
import { NewTravel } from "components/Dashboard/NewTravel";
import { TravelComp } from "../Dashboard/TravelComp";
import { useMainData } from "provider/MainDataProvider";

export const TravelInfo = () => {
  const { showFeedback } = useMainData();

  const [travelInfo, setTravelInfo] = useState({});
  const [travelUpdated, setTravelUpdated] = useState();
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState(false);

  const queryClient = useQueryClient();
  const params = useParams();
  const idTravel = params.idTravel;

  const {
    isLoading: isLoading,
    isError:isError,
    data: travelData,
  } = useQuery("travelData",  () => {
    return api.get({route:`travel/${idTravel}`,hasToken:true})
  }
);

  console.log("travelData")
  console.log(travelData)
  const [dialog, setDialog] = useState(false);
  travelInfo.id = 0;
  if (params.idTravel) {
    travelInfo.id = parseInt(params.idTravel);
  }

  const navigate = useNavigate();
  const travelUrl = `${url_prefix}/travel/${travelInfo.id}`;

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;

  // useEffect(() => {
  //   setDialog(false);
  // }, []);

  const onChange = ({ target: { name, value } }) => {
    setTravelUpdated({ ...travelUpdated, [name]: value });
  };


  const updateTravel = async (travel) => {
    api.update({route:`travel/${idTravel}`, id:travel.id,body:travel,idTravel:idTravel ,hasToken:true})
  };

  const deleteTravel = async () => {
   api.delete({route:`travel/${idTravel}`, id:idTravel, idTravel:idTravel ,hasToken:true})
  };

  const updateTravelMutation = useMutation(updateTravel, {
    onSuccess: (travelUp) => {
      setError(false);
      setTravelInfo(travelUp);

    },

    onError: (errorFetch) => {
      setErrorMsg(errorFetch);
      setError(true);
    },
  });

  const deleteTravelMutation = useMutation(deleteTravel, {
    onSuccess: () => {
      setError(false);
      setDialog(false);
      navigate("/dashboard/travel");
    },

    onError: (errorFetch) => {
      setErrorMsg(errorFetch);
      setError(true);
      setDialog(false);
    },
  });
  const [customListTags, setCustomListTags] = useState([]);
  const listTags = tagList.placeTagList;

  const onSubmit = (event) => {
    if (event) {
      event.preventDefault();
    }
    // updateTravelMutation.mutate(travelUpdated);
    updateTravel().then((res) => navigate("/dashboard/travel"));
  };

  return (
    <>
      <Container>
      {!isLoading && travelData ?
      (
        <>
        <Typography variant="h5">{travelData?.name}</Typography>

        {dialog ? (
          <AlertDialog
            activate={true}
            dialogTitle={"Êtes-vous sûr.e de votre coup ?"}
            dialogDescription={"Toutes vos données seront perdues :("}
            onCloseYesAction={() => {
              deleteTravelMutation.mutate();
            }}
            onCloseNoAction={() => setDialog(false)}
          />
        ) : null}

      <TravelComp travel={travelData} onSubmitAction={onSubmit} />


       {!isLoading && travelData.Travel_Traveler.id_permission === 2 ? (

         <Box>
       
        <Button
          variant="contained"
          data-cy="deleteAccountButton"
          onClick={() => {
            api
              .delete({
                route: Travel.routeName,
                id: travelInfo.id,
              })
              .then(() => {
                showFeedback("Voyage supprimé avec succès !");
              });
          }}
          color="error"
          sx={{ mt: 3, mb: 2 }}
        >
          Supprimer le voyage
        </Button>
        </Box>) : null }
        </>
         ) : (
          <Typography>LOADING....</Typography>
        )}
      </Container>
      <Divider />
      {!isLoading && travelData.Travel_Traveler.id_permission === 2 ? (

      <Container
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
        }}
      >
        <Typography variant="h5">Publication du voyage</Typography>
        <Button
          variant="contained"
          sx={{ mt: 3, mb: 2 }}
          onClick={() => {
            api
              .create({
                route: "clone",
                body: { is_public: true },
                idTravel: travelData?.id,
              })
              .then(() => {
                showFeedback("Voyage publié avec succès !");
              });
          }}
        >
          {travelData?.id_public_travel
            ? "Mettre à jour la publication"
            : "Publier mon voyage"}
        </Button>
        {travelData?.id_public_travel && (
          <Button
            variant="contained"
            color="error"
            sx={{ mt: 3, mb: 2 }}
            onClick={() => {
              api
                .delete({
                  route: Travel.routeName,
                  id: travelData?.id_public_travel,
                })
                .then(() => {
                  showFeedback("Publication supprimée avec succès !");
                });
            }}
          >
            Supprimer la publication
          </Button>
        )}
         
      </Container>
      ) : null }
    </>
  
  );
  
};
