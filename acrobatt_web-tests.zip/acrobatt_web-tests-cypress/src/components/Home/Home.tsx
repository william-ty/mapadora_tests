import React from 'react';

import { ViewHomePublicTravels } from '../../views/ViewHomePublicTravels';

const Home = () => {

    return <div className=""><ViewHomePublicTravels/></div>
};

export default Home;
