import {Point} from '../../src/model/Point'
     const createPointWithLonLat =  (lon,lat) => {

      return new Point( {
            crs: {
                type: "name",
                properties: {
                    name: "EPSG:4326"
                }
            },
            type: "Point",
            coordinates: [
                lon,
                lat
            ]
        })

    }



export {createPointWithLonLat};