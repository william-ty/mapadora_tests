// Load saved points
import { saveInterestPoint } from "./saveInterestPoint";
import api from "../../../api/api";
import { InterestPoint } from "../../../model/InterestPoint";

// export const loadInterestPoint = async (map: any) => {
//   const points = await api.get(InterestPoint.routeName);
//   points.map((point: InterestPoint) => {
//     return saveInterestPoint(map, point);
//   });
// };


