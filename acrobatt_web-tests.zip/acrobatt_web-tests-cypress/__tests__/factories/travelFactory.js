import {Travel} from '../../src/model/Travel'

export const tourDuMontBlanc = () => {
    return  new Travel({
        id: 1,
        name: "Tour du Mont Blanc",
        duration: 10,
        start_date: "",
        end_date: "",
        stepsNumber: 8,
        is_public: true,
        is_album_public: true,
        path_uid: "",
        commentary: "",
        path: "../../../img/static/publicTravels/montBlanc.jpg",
        id_traveltag: 4,
      })
}