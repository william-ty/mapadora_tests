
import * as React from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Icon from '@mui/material/Icon';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItem from '@mui/material/ListItem';

export const TagHeader = () => {

  return (
    <>
      <Box display="flex"
        sx={{ mt: 2 }}
      >
        <ListItem
          sx={{ backgroundColor: 'primary.main' }}
        >
          <ListItemButton>
            <ListItemText sx={{ flex: 5, color: "primary.lightest" }} primary={'Nom du label'} />
          </ListItemButton>
        </ListItem>
        {/* <Button variant='contained' sx={{ mx: 1, color: "primary.lightest" }}
          onClick={alert}>
          <Icon>delete</Icon>
        </Button> */}
        {/* <Button variant='text' sx={{ px: 1, color: "transparent", backgroundColor: "transparent", "&:hover": { backgroundColor: 'transparent', cursor: 'default' } }}>
        </Button> */}
      </Box>
    </>

  );
};