export const signin = async (credentials) => {
  const apiUrl = Cypress.env("baseApiUrl");
  let token = "";

  cy.clearLocalStorage();

  cy
    .request("POST", apiUrl + "traveler/signin", credentials)
    .then((resp) => {
      console.log(resp.body.token);
      token = resp.body.token.toString();
      localStorage.setItem("token", token);
      return token;
    })
    .then((token) => {
      expect(localStorage.getItem("token")).to.eq(token);
      if (localStorage.getItem("token")) {
        cy.visit("dashboard");
      }
    });
};
