
import * as React from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Icon from '@mui/material/Icon';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Checkbox from '@mui/material/Checkbox';
import ListItem from '@mui/material/ListItem';
import { Task } from 'model/Task';
import { EditTodo } from './EditTodo';
import { SelectChangeEvent, Typography } from '@mui/material';
import Chip from '@mui/material/Chip';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { TaskListTag } from 'model/TaskListTag';

export type ToggleComplete = (selectedTodo: Task) => void;
export type HandleDelete = (selectedTodo: Task) => void;
export type HandleUpdate = (selectedTodo: Task) => void;

export type AddTodo = (newTodo: Task) => void;

interface TodoListItemProps {
  todo: Task;
  toggleComplete: ToggleComplete;
  handleDelete: HandleDelete;
  handleUpdate: HandleUpdate;
  newTodoName?: string;
  newTodoDate?: Date | null;
  handleNameChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleDateChange?: (date: Date | null, keyboardInputValue?: string | undefined) => void;
  onChangeTag: ({ target: { name, value }, }: SelectChangeEvent<string>) => void;
  tags: TaskListTag[];
  handleClickTagToAdd: (tag: TaskListTag, selectedTask: Task) => void;
  handleDeleteTagFromTask: (tag: TaskListTag, selectedTodo: Task) => void;
}

export const TodoListItem: React.FC<TodoListItemProps> = ({
  todo,
  toggleComplete,
  handleDelete,
  handleUpdate,
  newTodoName,
  newTodoDate,
  handleNameChange,
  handleDateChange,
  handleClickTagToAdd,
  onChangeTag,
  tags,
  handleDeleteTagFromTask
}) => {

  const [editMode, setEditMode] = React.useState<boolean>(false);

  const labelId = `checkbox-list-secondary-label-${todo}`;


  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const openMoreTag = Boolean(anchorEl);
  const handleClickMoreTag = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseMoreTag = () => {
    setAnchorEl(null);
  };
  const [tagsNotIncluded, setTagsNotIncluded] = React.useState<TaskListTag[]>();

  React.useEffect(() => {
    // console.log(todo)
    if (tags) {
      if (todo.TaskListTags) {
        if (todo.TaskListTags.length > 0) {

          setTagsNotIncluded(
            tags.filter((tag) => {
              let res = true;
              todo.TaskListTags.forEach((todoTag) => {
                if (todoTag.id === tag.id) res = false;
              });
              return res;
            })
          );

        } else {
          setTagsNotIncluded(tags);
        }
      }
    }
  }, [tags, todo])

  // React.useEffect(() => {
  //   console.log(tagsNotIncluded)
  // }, [tagsNotIncluded])

  return (
    <>
      <Box display="flex"
        sx={{ mb: 1 }}
      >
        {editMode === true ?
          <ListItem
            sx={{
              backgroundColor: 'primary.lightest', p: 1.5
            }}
          // key={todo}
          >
            <EditTodo
              newTodoName={newTodoName!}
              newTodoDate={newTodoDate!}
              handleNameChange={handleNameChange!}
              handleDateChange={handleDateChange!}
              // handleClickTagToAdd={handleClickTagToAdd}
              onChangeTag={onChangeTag}
              tags={tags}
            />

          </ListItem>
          :
          <ListItem
            sx={{
              backgroundColor: 'primary.lightest',
              pointer: 'default',
              p: 1,
              pl: 2,
              // textDecoration: 'line-through'
            }}
            // key={todo}
            // onClick={() => toggleComplete(todo)}
            secondaryAction={
              // editMode &&
              <Checkbox
                onChange={() => toggleComplete(todo)}
                edge="end"
                checked={todo.is_terminated === true}
                inputProps={{ 'aria-labelledby': labelId }}
              />
            }
            disablePadding
          >
            {/* <ListItemButton> */}
            <ListItemText sx={{ flex: 3 }} primary={`"${todo.name}"`} />
            <Box sx={{ flex: 3, display: "flex", alignItems: "center" }}>
              <Box>
                <IconButton
                  aria-label="more"
                  id="long-button"
                  aria-controls={openMoreTag ? 'long-menu' : undefined}
                  aria-expanded={openMoreTag ? 'true' : undefined}
                  aria-haspopup="true"
                  onClick={handleClickMoreTag}
                  sx={{ border: 'solid 1px', borderColor: 'gray.main', padding: 0.3, mr: 1 }}
                  size='small'
                >
                  {openMoreTag ?
                    <Icon fontSize='medium'>remove</Icon>
                    :
                    <Icon fontSize='medium'>add</Icon>
                  }
                </IconButton>
                <Menu
                  id="long-menu"
                  MenuListProps={{
                    'aria-labelledby': 'long-button',
                  }}
                  anchorEl={anchorEl}
                  open={openMoreTag}
                  onClose={handleCloseMoreTag}
                  PaperProps={{
                    style: {
                      maxHeight: '20rem',
                      width: 'auto',
                      maxWidth: '10rem',
                      padding: '0 0.1rem'
                    },
                  }}
                >
                  {tagsNotIncluded && tagsNotIncluded.map((tag, key) => {

                    return <Chip variant="outlined" key={key} sx={{
                      m: 0.3, backgroundColor: "secondary.darky", color: 'secondary.lightest', border: "solid 1px", borderColor: "secondary.light", "&:hover": {
                        backgroundColor: 'secondary.light', color: 'secondary.darker'
                      }
                    }} label={`${tag.name}`} onClick={() => handleClickTagToAdd(tag, todo)} />
                  })}
                </Menu>
              </Box>

              {todo.TaskListTags && todo.TaskListTags!.length > 0 ?
                <ListItemText>
                  {todo.TaskListTags?.map((tag, key) => <Chip key={key} sx={{ mr: 0.3, my: 0.3, backgroundColor: "secondary.lighter", border: "solid 1px", borderColor: "secondary.light" }} label={`${tag.name}`} onDelete={() => handleDeleteTagFromTask(tag, todo)} />)}
                </ListItemText>
                :
                <ListItemText sx={{ flex: 3 }} primary={"Aucun label"} />
              }
            </Box>
            <ListItemText sx={{ flex: 2 }} primary={todo.execution_date} />
            {/* </ListItemButton> */}
          </ListItem>
        }
        {editMode === false ?
          <>
            <Button variant='contained' sx={{ mx: 1 }} onClick={() => handleDelete(todo)}>
              <Icon>delete</Icon>
            </Button>
            <Button
              variant='contained'
              sx={{ px: 1 }}
              onClick={() => { editMode ? setEditMode(false) : setEditMode(true) }}
            >
              <Icon>edit</Icon>
            </Button>
          </>
          :
          <Button
            variant='contained'
            sx={{ px: 3.5, ml: 1 }}
            onClick={() => {
              console.log(todo)
              handleUpdate(todo);
              editMode ? setEditMode(false) : setEditMode(true);
            }}
          >
            <Typography sx={{ fontWeight: "bold" }}>Confirmer</Typography>
          </Button>
        }
      </Box>
    </>
  );
};