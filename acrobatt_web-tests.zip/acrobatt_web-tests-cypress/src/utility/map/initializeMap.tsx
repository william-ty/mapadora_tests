  // import { loadInterestPoint } from "./interestPoint/loadInterestPoint";
  // import { loadStepPlanner } from "./step/loadStepPlanner";

export function initializeMap(mapboxgl: any, map: any) {
  // loadStepPlanner(map);
  //  loadInterestPoint(map);
}
