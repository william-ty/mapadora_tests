const apiUrl = Cypress.env("baseApiUrl");
Cypress.Commands.add("loginJohnDoe", () => {

  cy.request({
    method: "POST",
    url: apiUrl + "traveler/signin",
    body: {
      email: "john@doe.com",
      password: "12345",
    },
  })
    .its("body")
    .then((body) => {
      localStorage.setItem("token", body.token);
    });
});
