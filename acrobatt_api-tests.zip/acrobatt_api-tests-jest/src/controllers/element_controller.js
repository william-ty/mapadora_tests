const AppController = require("./app_controller");

class ElementController extends AppController {
  constructor(model) {
    super(model);
  }
}

module.exports = ElementController;
