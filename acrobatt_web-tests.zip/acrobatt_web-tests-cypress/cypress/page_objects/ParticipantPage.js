/// <reference types="cypress" />

export class ParticipantPage {
  navigateTo(idTravel) {
    cy.visit(`dashboard/travel/${idTravel}/participants`);
    cy.get('[data-cy="addParticipantText"]').should("be.visible");
  }

  addParticipantWithEmail(participant) {
    cy.get("[data-cy=addParticipantButton]").click();
    cy.get("[data-cy=inputParticipantName]").type(participant.name);
    cy.get("[data-cy=inputParticipantEmail]").type(participant.email);
    cy.get("[data-cy=submitParticipant]").click()

    cy.get("[data-cy=participantInWaiting]")
      .should("contain.text", participant.name)
      .should("contain.text", participant.email);
  }

  addParticipantWithoutEmail(participant) {
    cy.get("[data-cy=addParticipantButton]").click();
    cy.get("[data-cy=inputParticipantName]").type(participant.name);
    cy.get("[data-cy=submitParticipant]").click()
    this.checkParticipantAcceptedListContent(participant.name)
  }

  checkParticipantAcceptedListContent(itemToFind){
    cy.get("[data-cy=participantAccepted]").should(
      "contain.text",
      itemToFind
    );
  }

  deleteParticipant(childNumber){
    cy.get(`:nth-child(${childNumber}) > .MuiButtonBase-root > [data-testid="GroupRemoveIcon"]`).click();
    cy.get("[data-cy=participantAcceptedList] li").should('have.length',2)
  }
}
