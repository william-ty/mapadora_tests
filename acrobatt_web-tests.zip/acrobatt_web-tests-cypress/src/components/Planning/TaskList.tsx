export {};
// import React, { useState } from "react";
// import { List } from "react-native-paper";
// import { useQuery } from "react-query";
// import api from "../../api/api";

// export const TaskList = (props) => {
//   //const [isTaskExpanded, setIsTaskExpanded] = useState(true);
//   const elementId = props.elementId;

//   const taskQuery = { data: [] };
//   /*
//   const taskQuery = useQuery<Task[], Error>(
//     ["tasks", 1 //TODO PUT TRAVEL ID TO CACHE NAME],
//     () => api.get({ route: Task.routeName })
//   );
//   */
//   const taskList = taskQuery.data?.filter((task) =>
//     elementId ? task.id_element === elementId : true
//   );

//   return (
//     <>
//       <List.Accordion
//         title="Tâches"
//         left={(props) => <List.Icon {...props} icon="format-list-checks" />}
//       >
//         {taskList && taskList.length > 0 ? (
//           taskList.map((task, idx) => <List.Item key={idx} title={task.name} />)
//         ) : (
//           <List.Item title={"Aucune tâche pour le moment"} />
//         )}
//       </List.Accordion>
//     </>
//   );
// };
// // <List.Item key={idx} title={task.name} />
// //  <List.Item key={idx} title={"Aucune tâche pour le moment"} />
