/* eslint-disable no-undef */
/// <reference types="cypress" />

import { SigninPage } from "../page_objects/SigninPage";
import { Credentials } from "../../src/model/Credentials";
import {createJohnDoe} from '../factories/Users'

describe("signin, signout etc", () => {
  const user = createJohnDoe();
  const signinPage = new SigninPage();



  it("Connexion utilisateur", () => {
    const credentials = new Credentials({
      email: user.email,
      password: user.password,
    });

    signinPage.navigateTo();
    signinPage.fillAndSubmit(credentials);

    
  });
});

// cy.get("[data-cy=deleteAccountButton]").click();
//     cy.get("[data-cy=alertDialog]").should("exist");
//     cy.get("[data-cy = okButton]").click();
//     cy.url().should("equal", Cypress.env("baseUrl"));
