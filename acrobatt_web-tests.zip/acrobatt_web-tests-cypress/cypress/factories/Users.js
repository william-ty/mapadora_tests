import { Traveler } from "../../src/model/Traveler";

export const createUtilisateur = () => {
  const traveler = new Traveler({
    firstname: "utilisateur",
    lastname: "test",
    email: "email@gmail.com",
    password: Cypress.env("utilisateurPassword"),
  });
  console.log(traveler);
  return traveler;
};

export const createJeanMartin = () => {
  return new Traveler({
    firstname: "Jean",
    lastname: "Martin",
    email: "jean@martin.com",
    password: Cypress.env("jeanPassword"),
  });
};

export const createJohnDoe = () => {
  return new Traveler({
    firstname: "John",
    lastname: "Doe",
    email: "john@doe.com",
    password: Cypress.env("johnDoePassword"),
  });
};

export const createLadyLovelace = () => {
  return new Traveler({
    firstname: "Lady",
    lastname: "Lovelace",
    email: "lady@lovelace.uk",
    password: "london",
  });
};
