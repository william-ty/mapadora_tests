export {};
// import React, { useState } from "react";
// import { List } from "react-native-paper";
// import { useQuery } from "react-query";
// import api from "../../api/api";
// import { Document } from "../../model/Document";
// import { InterestPoint } from "../../model/InterestPoint";

// export const InterestPointList = (props) => {
//   //const [isPoiExpanded, setIsPoiExpanded] = useState(true);
//   const stepId = props.stepId;
//   const navigation = props.navigation;

//   const interestPointQuery = useQuery<InterestPoint[], Error>(
//     ["interestpoints", 1 /*TODO PUT TRAVEL ID TO CACHE NAME*/],
//     () => api.get({ route: InterestPoint.routeName })
//   );
//   const interestPointList = Array.isArray(interestPointQuery.data) // TODO: REMOVE WHEN API RETURN []
//     ? interestPointQuery.data?.filter(
//         (poi) => /*stepId ? poi.step_id === stepId :*/ true
//       )
//     : [];

//   return (
//     <>
//       <List.Accordion
//         title="Points d'intérêt"
//         left={(props) => <List.Icon {...props} icon="pin" />}
//       >
//         {interestPointList && interestPointList.length > 0 ? (
//           interestPointList.map((poi, idx) => {
//             return (
//               <List.Item
//                 key={idx}
//                 title={poi.element_interestpoint?.name}
//                 onPress={() =>
//                   navigation.navigate("InterestPointDetails", {
//                     id: poi.id,
//                   })
//                 }
//               />
//             );
//           })
//         ) : (
//           <List.Item title={"Aucun point d'intérêt pour le moment"} />
//         )}
//       </List.Accordion>
//     </>
//   );
// };
