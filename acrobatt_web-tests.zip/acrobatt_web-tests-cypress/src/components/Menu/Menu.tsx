import React from "react";
import { Link } from "react-router-dom";
import AccountMenu from "./AccountMenu";

const Menu = () => {
  const userLoggedIn = false;
    // console.log(userLoggedIn)
  return (
 
      <div>
    {/* <ul>
      <li key="home">
        <Link to="/">Accueil 🏠</Link>
      </li>
      <li key="planning">
        <Link to="/planning">Plannifier un voyage ! 🌴</Link>
      </li>
    </ul>
    { userLoggedIn && <AccountMenu /> } */}
          </div>
  );
};

export default Menu;
