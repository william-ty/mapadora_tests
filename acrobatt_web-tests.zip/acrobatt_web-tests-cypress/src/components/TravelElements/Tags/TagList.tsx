import { Box, Typography } from "@mui/material";
import { TaskListTag } from 'model/TaskListTag';
import React from "react";
import { HandleDelete, HandleUpdate } from "./TagListItem";
import { TagListItem } from "./TagListItem";

interface TagListProps {
  tags?: Array<TaskListTag>;
  handleDelete: HandleDelete;
  handleUpdate: HandleUpdate;
}



export const TagList: React.FC<TagListProps> = ({
  tags,
  handleDelete,
  handleUpdate
}) => {
  return (
    <Box sx={{ my: 2 }}>
      {tags ? tags?.map(tag => (
        <TagListItem
          key={tag.id}
          tag={tag}
          handleDelete={handleDelete}
          handleUpdate={handleUpdate}
        />
      )) : <Typography variant="subtitle2">Aucuns labels pour le moment.</Typography>}
    </Box>
  );
};