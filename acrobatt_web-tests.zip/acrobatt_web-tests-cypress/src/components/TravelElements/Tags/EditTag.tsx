import React, { ChangeEvent } from "react";
import { TextField } from "@mui/material";


export const EditTag = ({ newTagName, handleNameChange }: {
  newTagName: string, handleNameChange: (e: ChangeEvent<HTMLInputElement>) => void
  ,
}) => {

  return (
    <>
      <TextField type="text" placeholder="Nom du label" value={newTagName} onChange={handleNameChange} />
    </>
  );
};