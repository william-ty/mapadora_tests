
import * as React from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Icon from '@mui/material/Icon';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Checkbox from '@mui/material/Checkbox';
import ListItem from '@mui/material/ListItem';

export const TodoHeader = () => {

  return (
    <>
      <Box display="flex"
        sx={{ mt: 3 }}
      >
        <ListItem
          sx={{ backgroundColor: 'primary.main' }}
          // key={todo}
          // onClick={() => toggleComplete(todo)}
          // secondaryAction={
          //   <Checkbox
          //     edge="end"
          //     // onChange={() => toggleComplete(todo)}
          //     checked={false}
          //     // onChange={handleToggle(value)}
          //     inputProps={{ 'aria-labelledby': 'checkbox-list-secondary-label-all' }}
          //   />
          // }
          disablePadding
        >
          <ListItemButton>
            {/* <ListItemAvatar>
              <Avatar
            alt={`Avatar n°${todo + 1}`}
            src={`/static/images/avatar/${todo + 1}.jpg`}
          />
            </ListItemAvatar> */}
            {/* <ListItemText id={labelId} primary={`Line item ${value + 1}`} /> */}
            <ListItemText sx={{ flex: 3, color: "primary.lightest" }} primary={'Nom de la tâche'} />
            <ListItemText sx={{ flex: 3, color: "primary.lightest" }} primary={'Labels associés'} />
            <ListItemText sx={{ flex: 4, color: "primary.lightest" }} primary={"Date d'execution"} />
          </ListItemButton>
        </ListItem>
        {/* <Button variant='contained' sx={{ mx: 1, color: "primary.lightest" }}
          onClick={alert}>
          <Icon>delete</Icon>
        </Button> */}
        {/* <Button variant='text' sx={{ px: 1, color: "transparent", backgroundColor: "transparent", "&:hover": { backgroundColor: 'transparent', cursor: 'default' } }}>
        </Button>
        <Button variant='text' sx={{ px: 1, color: "transparent", backgroundColor: "transparent", "&:hover": { backgroundColor: 'transparent', cursor: 'default' } }}>
        </Button> */}
      </Box>
    </>

  );
};