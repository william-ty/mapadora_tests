export { default as IconArrowDownStroke } from "./IconArrowDownStroke";
export { default as IconArrowLeftStroke } from "./IconArrowLeftStroke";
export { default as IconArrowRightStroke } from "./IconArrowRightStroke";
export { default as IconCloseStroke } from "./IconCloseStroke";
export { default as IconPercentAltStroke } from "./IconPercentAltStroke";
