import React from "react";
import frLocale from 'date-fns/locale/fr';
import { Button, FormControl, TextField, Box, Typography, SelectChangeEvent } from "@mui/material";
import { AddTodo } from "./TodoListItem";
import { EditTodo } from "./EditTodo";
import { TaskListTag } from "model/TaskListTag";

interface AddTodoFormProps {
  newTodoName: string;
  newTodoDate: Date;
  handleNameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleDateChange: (date: Date | null, keyboardInputValue?: string | undefined) => void;
  handleSubmit: React.MouseEventHandler<HTMLButtonElement> | undefined;
  onChangeTag: ({ target: { name, value }, }: SelectChangeEvent<string>) => void;
  tags: TaskListTag[];
  handleClickTagsToAdd: (tag: TaskListTag) => void;
  tagsToAdd?: TaskListTag[];
  setTagsToAdd: (value: TaskListTag[]) => void;
}


export const AddTodoForm: React.FC<AddTodoFormProps> = ({ newTodoName, newTodoDate, handleNameChange, handleDateChange, handleSubmit, onChangeTag, tags, tagsToAdd, setTagsToAdd, handleClickTagsToAdd }) => {


  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "row" }}>
        <EditTodo
          newTodoName={newTodoName}
          newTodoDate={newTodoDate!}
          handleNameChange={handleNameChange}
          handleDateChange={handleDateChange}
          onChangeTag={onChangeTag}
          tags={tags}
          tagsToAdd={tagsToAdd}
          setTagsToAdd={setTagsToAdd}
          handleClickTagsToAdd={handleClickTagsToAdd}
        />
        <Button sx={{ ml: 2, height: "3.4rem" }} variant='contained' type="submit" onClick={handleSubmit}>
          Ajouter
        </Button>
      </Box>
    </>
  );
};