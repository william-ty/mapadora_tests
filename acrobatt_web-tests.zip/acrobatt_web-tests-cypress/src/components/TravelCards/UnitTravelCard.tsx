import { Travel } from "../../model/Travel";
import {Step} from '../../model/Step'
import { CardSubHeader } from "./SubHeaderCard";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import {Traveler} from '../../model/Traveler'

import ExploreIcon from "@mui/icons-material/Explore";
import { url_prefix } from "../../api/util";
import { InvitationsButtons } from "./InvitationsButtons";
import { PrivateButtons } from "./PrivateButtons";
import { PublicButtons } from "./PublicButtons";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";

export enum EnumPublicPrivate {
  Public,
  Private,
  DealWithInvitations,
}

type UnitTravelCardsProps = {
  typeOfComponent: any;
  travel: Travel;
  refetchInvitation:any;
  user:Traveler|null;
  idParticipant?: number;
};

const UnitTravelCards = (props: UnitTravelCardsProps) => {
const travel = props.travel;
console.log('listOfSteps')
console.log(props.travel.listOfSteps)
if(props.travel){
  return (
    <Card
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
      key={travel.id}
    >
      <CardMedia
        component="img"
        sx={{
          // 16:9
          pt: 2,
        }}
        height="220"
        image={
          travel.path
            ? props.typeOfComponent === EnumPublicPrivate.Private ||
              EnumPublicPrivate.DealWithInvitations
              ? `${url_prefix}/${travel.path}`
              : `${travel.path}`
            : "../../../img/static/publicTravels/montBlanc.jpg"
        }
        alt="random"
      />
      <CardContent
        sx={{
          flexGrow: 3,
          display: "flex",
          flexDirection: "column",
          pt: 1,
          px: 2,
          pb: 0,
        }}
      >
        <Box mb={1} display="flex" alignItems="center">
          <ExploreIcon sx={{ marginRight: 1 }} />
          <Typography variant="h6" component="h2">
            {travel.name ? travel.name : "Voyage"}
          </Typography>
          {props.typeOfComponent === EnumPublicPrivate.Private &&
          travel.Travel_Traveler &&
          travel.Travel_Traveler.id_permission === 2 ? (
            <AdminPanelSettingsIcon sx={{ ml: "5px" }} />
          ) : null}
        </Box>
        {props.travel ?
        <CardSubHeader listOfSteps={props.travel.listOfSteps} travel={travel} />
        : <p>LOADING...</p>}
        {/* <TagList travel={travel} /> */}
      </CardContent>
      <CardActions>
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            width: "100%",
            p: 1,
            // my: 2,
            // mx: 5,
          }}
        >
          {props.typeOfComponent === EnumPublicPrivate.Private ? (
            <PrivateButtons travel={travel} />
          ) : props.typeOfComponent === EnumPublicPrivate.DealWithInvitations &&
            props.idParticipant ? (
            <InvitationsButtons
            user = {props.user}
            refetchInvitation={props.refetchInvitation}
              travel={travel}
              idParticipant={props.idParticipant}
            />
          ) : (
            <PublicButtons
              redirectTo={`${
                travel.is_public ? `travel/${travel.id}` : `${travel.id}`
              }`}
            />
          )}
        </Box>
      </CardActions>
    </Card>
  )} else {
    return(<p>LOADING...</p>)
  }
};

export default UnitTravelCards;
