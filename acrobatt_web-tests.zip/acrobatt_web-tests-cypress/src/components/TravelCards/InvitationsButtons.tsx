import { Button, Typography, Grid } from "@mui/material";
import TravelExploreIcon from "@mui/icons-material/TravelExplore";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import ExploreIcon from "@mui/icons-material/Explore";
import { Link as RouterLink, Navigate, useNavigate } from "react-router-dom";
import { Travel } from "../../model/Travel";
import { url_prefix } from "../../api/util";
import { useAuth } from "../../provider/AuthProvider";
import api from "../../api/api";
import { useNotificationQuery } from "../Dashboard/NotificationHook";
import { Traveler } from "model/Traveler";


type ButtonProps = {
  travel: Travel;
  idParticipant:number
  user:Traveler|null;
  refetchInvitation:any;
};

export const InvitationsButtons = (props: ButtonProps) => {

    const navigate = useNavigate();

   

    const postResponse = async (hasRefused:boolean) => { 
      if(props.user){
      api.create({
        route:`traveler/${props.user.id}/invitations`,
        hasToken:true,
        body:{
          idTravel:props.travel.id,
          hasRefused:hasRefused,
          idParticipant:props.idParticipant
      }
      }).then(() => {
        props.refetchInvitation();
      })
    }

    
    
    }

  const acceptInvitation = () => {
    postResponse(false).then((res: any) => {
            navigate('/dashboard/travel');
  })
}

  const refuseInvitation = () => {
    postResponse(true).then((res: any) => {
      navigate('/dashboard/travel');
  })
}

  return (
    <Grid container spacing={1}>
      <Grid item xs={12}>
        <Button variant="contained" endIcon={<TravelExploreIcon />}>
          <Typography
            sx={{ textDecoration: "none", color: "primary.darker" }}
            component={RouterLink}
            to={`${props.travel.id}`}
          >
            Voir
          </Typography>
        </Button>
      </Grid>
      <Grid item>
        <Button
        data-testId="button-accept"
        data-cy="acceptInvitationButton"
          variant="contained"
          color="success"
          onClick={acceptInvitation}
          endIcon={<CheckCircleOutlineIcon />}
        >
          <Typography
            sx={{ textDecoration: "none", color: "primary.darker" }}
            
          >
            Accepter
          </Typography>
        </Button>
      </Grid>
      <Grid item>
        <Button
          variant="contained"
          color="error"
          onClick={refuseInvitation}
          endIcon={<HighlightOffIcon />}
        >
          <Typography
            sx={{ textDecoration: "none", color: "primary.darker" }}
            
          >
            Refuser
          </Typography>
        </Button>
      </Grid>
    </Grid>
  );
};
