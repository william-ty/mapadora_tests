import React from 'react';

import {screen, render} from '@testing-library/react';
import  UnitTravelCard from "../../src/components/TravelCards/UnitTravelCard"
import {tourDuMontBlanc} from "../factories/travelFactory"
import {EnumPublicPrivate} from '../../src/components/TravelCards/TravelCards'
import { MemoryRouter as Router } from 'react-router-dom';

test("la travelCard publique doit faire apparaître le bouton 'Voir'", () => {
    //arrange
    const travel = tourDuMontBlanc();
    //act
    render(<Router><UnitTravelCard travel={travel} idParticipant={2} typeOfComponent={EnumPublicPrivate.Public} /></Router>)
    //assert
    expect(screen.getByTestId('button-content').innerHTML).toContain("Voir");
});

test("la travelCard privée doit faire apparaître le bouton 'Editer'", () => {
    //arrange
    const travel = tourDuMontBlanc();
    //act
    render(<Router><UnitTravelCard travel={travel} idParticipant={2} typeOfComponent={EnumPublicPrivate.Private} /></Router>)
    //assert
    expect(screen.getByTestId('button-edit').innerHTML).toContain("Editer");
});


test("la travelCard d'invitation doit faire apparaître le bouton 'Accepter", () => {
    //arrange
    const travel = tourDuMontBlanc();
    //act
    render(<Router><UnitTravelCard travel={travel} idParticipant={2} typeOfComponent={EnumPublicPrivate.DealWithInvitations} /></Router>)
    //assert
    expect(screen.getByTestId('button-accept').innerHTML).toContain("Accepter");
});