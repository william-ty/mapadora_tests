
export const homeContent = {

    box1: {
        title: "Inspirez-vous",
        image: require('../img/static/content/home/box-inspiration.jpg'),
        text: "Trouvez de l’inspiration pour vos prochaines vacances, road-trips ou tours du monde, grâce aux voyages publics partagés par d’autres utilisateurs. Vous pouvez en copier un ou en créer un nouveau, dans les 2 cas, votre voyage est 100 % personnalisable.",
    },

    box2: {
        title: "Planifiez",
        image: require('../img/static/content/home/box-planner.jpg'),
        text: "Ajoutez les lieux à ne pas manquer avec les points d’intérêt. Ajouter des étapes et relier les entre elles avec des trajets pour former votre itinéraire de voyage. Associez facultativement des informations aux éléments du voyage (points d’intérêt, étapes et trajets) tel qu’une description, une date, une liste des choses à faire/à ne pas oublier et des documents.",
    },

    box3: {
        title: "Voyagez",
        image: require('../img/static/content/home/box-travel.jpg'),
        text: "Tout au long du voyage, suivez votre itinéraire et retrouvez d’un coup d’œil les informations associées avec l’application mobile IOS et Android. Prenez des photos géolocalisés ou transférez des photos existantes. Tenez à jour votre journal de voyage. En fin de voyage retrouvez les éléments les plus pertinents dans votre album de voyage.",
    },

    box4: {
        title: "Partagez",
        image: require('../img/static/content/home/box-share.jpg'),
        text: "Dès la phase de planification, vous pouvez inviter d’autres utilisateurs afin de planifier le voyage en commun. Durant tous le voyage, tous les participants ont accès aux même informations qu’ils peuvent les modifier. Vous pouvez également partager l’album de voyage à des utilisateurs non inscrit à l’aide d’un lien de partage pour qu’il puisse suivre votre itinéraire en direct.",
    },

    box5: {
        title: "Gérez vos dépenses",
        image: require('../img/static/content/home/box-money.png'),
        text: "Notre application intègre également un service de gestion des dépenses. À tout moment vous pouvez consulter l’état de vos comptes ou ajouter une dépense avec son auteur, sa catégorie, son montant et ses bénéficiaires parmi les participants au voyage.",
    },

}
