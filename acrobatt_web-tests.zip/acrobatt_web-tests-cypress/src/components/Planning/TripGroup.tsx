import { Box, Paper, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { DragDropContext, Droppable, DropResult } from "react-beautiful-dnd";
import { useMutation, useQueryClient } from "react-query";
import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import api from "../../api/api";
import { Trip } from "../../model/Trip";
import { Step } from "../../model/Step";
import { useData } from "../../provider/DataProvider";
import { useMainData } from "../../provider/MainDataProvider";
import { TripItem, TripStep } from "../MapItems/DraggableListItem";
import StyledMenu from "../MapItems/StyledMenu";
import { forEach } from "cypress/types/lodash";

export const TripGroup = (props: any) => {
  const { idTravel } = useParams();
  const id_travel = parseInt(idTravel!);

  const { map } = useData();
  const navigate = useNavigate();

  const {
    tripSteps,
    isEditable,
  }: {
    tripSteps: TripStep[];
    isEditable: boolean;
  } = useOutletContext();

  const queryClient = useQueryClient();

  // // const deleteTrip = useMutation(api.delete, {
  // //   onSuccess: (trip, { id }) => {
  // //     queryClient.setQueryData<Step[]>(
  // //       ["trip", id_travel],
  // //       (trip) => trip!.filter((poi) => poi.id !== id)
  // //     );
  // //   },
  // // });

  // // const onLocate = (item: Step | Trip) =>
  // //   map?.current.flyTo({
  // //     center: item.point.coordinates,
  // //     zoom: map?.current.getZoom(),
  // //     pitch: map?.current.getPitch(),
  // //     bearing: map?.current.getBearing(),
  // //   });
  // // const onDelete = (item: Step | Trip) =>
  // //   item?.id &&
  // //   deleteTrip.mutate({
  // //     route: Trip.routeName,
  // //     id: item.id,
  // //     idTravel: id_travel,
  // //   });
  const onEdit = (itemId: number) => navigate(`${itemId}/edit`);
  const onRead = (itemId: number) => navigate(`${itemId}`);

  // useEffect(() => {
  //   console.log(tripSteps)
  // }, [tripSteps]);

  // steps!.filter((step) => step.id_trip)

  return (
    <Box
      sx={{
        backgroundColor: "accent.lighter",
        padding: 1,
        borderRadius: "4px",
      }}
      classes={styles.flexPaper}
    >
      {tripSteps && tripSteps.length > 1 ? (
        tripSteps.map(
          (item, index) =>
            item.departure && (
              <TripItem
                key={item.trip.id}
                icon={"location_on_icon"}
                tripInfos={item}
                styledMenu={
                  <>
                    {/* {isEditable && ( */}
                    <StyledMenu
                      // onLocate={() => onLocate(item)}
                      onEdit={() => item.trip?.id && onEdit(item.trip.id)}
                      onRead={() => item.trip?.id && onRead(item.trip.id)}
                      color="accent"
                      type="trip"
                    />
                    {/* )} */}
                  </>
                }
              />
            )
        )
      ) : (
        <Typography sx={{ ml: 2 }}>Aucun trajet à afficher</Typography>
      )}
    </Box>
  );
};

const styles = {
  flexPaper: {
    flex: 1,
    margin: 16,
    minWidth: 350,
  },
};
