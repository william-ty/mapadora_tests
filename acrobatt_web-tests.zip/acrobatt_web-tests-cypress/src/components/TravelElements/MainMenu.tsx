import * as React from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import { Link, Outlet, useParams } from "react-router-dom";
import { Container, Divider, Typography } from "@mui/material";
import TabPanel from "@mui/lab/TabPanel";
import { Travel } from "model/Travel";
import { useQuery } from "react-query";
import api from "api/api";

export const MainMenu = () => {
  const [value, setValue] = React.useState("one");
  let params = useParams();
  const id_travel = parseInt(params.idTravel ? params.idTravel : "");
  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const {
    isLoading: travelIsLoading,
    isError: travelError,
    data: travelData,
  } = useQuery("travelData", () => {
    if (id_travel) {
      return api.get({ route: "", idTravel: id_travel });
    } else {
      return undefined;
    }
  });

  return (
    <Container>
      <Paper sx={{ width: "100%", p: 1, backgroundColor: "secondary.lighter" }}>
        {travelData && travelData.name ? (
          <Typography sx={{ my: "10px" }} variant="h5">
            {travelData?.name}
          </Typography>
        ) : null}
        <Button
          id="one"
          size="small"
          color="primary"
          variant="contained"
          component={Link}
          sx={{ textDecoration: "none" }}
          to="info"
        >
          Informations
        </Button>
        <Button
          size="small"
          color="primary"
          variant="contained"
          component={Link}
          data-cy="participantButton"
          sx={{ textDecoration: "none", ml: 2 }}
          to="participants"
        >
          Participants
        </Button>
        <Button
          size="small"
          color="primary"
          variant="contained"
          component={Link}
          sx={{ textDecoration: "none", ml: 2 }}
          to="documents"
        >
          Documents
        </Button>
        <Button
          size="small"
          color="primary"
          variant="contained"
          component={Link}
          sx={{ textDecoration: "none", mx: 2 }}
          to="taches"
        >
          Tâches
        </Button>
        <Button
          size="small"
          color="primary"
          variant="contained"
          component={Link}
          sx={{ textDecoration: "none", mr: 2 }}
          to={`album`}
        >
          Album de voyage
        </Button>
        <Button
          size="small"
          color="secondary"
          variant="contained"
          component={Link}
          sx={{
            textDecoration: "none",
            "&:hover": { backgroundColor: "secondary.darky" },
          }}
          to={`/travel/${id_travel}`}
        >
          Planifier
        </Button>
        {/* </Tabs> */}
      </Paper>
      <Divider flexItem sx={{ mt: 3 }} />
      <Outlet />
    </Container>
  );
};
