/// <reference types="cypress" />
import {SignupPage} from '../page_objects/SignupPage'
import {createUtilisateur} from '../factories/Users'
describe("signup nouvel utilisateur", () => {
    const signupPage = new SignupPage();
    const user = createUtilisateur();


    it("Création de compte utilisateur", () => {
        signupPage.navigateTo();  
        signupPage.isNotUserBar();
        signupPage.fillAndSubmit(user);
  
    })
})