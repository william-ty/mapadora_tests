import react, { useEffect, useState } from "react";
import {
  Button,
  Box,
  TextField,
  Typography,
  Select,
  InputLabel,
  MenuItem,
  SelectChangeEvent,
  FormControl,
  OutlinedInput
} from "@mui/material";
import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import { InterestPoint } from "../../../model/InterestPoint";
import { Step } from "../../../model/Step";
import { Element } from "../../../model/Element";
import { Point } from "../../../model/Point";
import { useMutation, useQueryClient, useQuery } from "react-query";
import api from "../../../api/api";
import { SelectedStep } from "./EditStep";
import EventIcon from "@mui/icons-material/Event";
import React from "react";

export type SelectedInterestPoint = {
  id?: number;
  element?: Element;
  point?: Point;
  order?: number;
  id_step?: number;
  day?: number;
};

export const EditInterestPoint = () => {
  const { idTravel } = useParams();
  const id_travel = parseInt(idTravel!);
  const navigate = useNavigate();
  const { id } = useParams();
  const selectedId = id ? parseInt(id) : null;

  const {
    interestPoints,
    steps,
  }: { interestPoints: InterestPoint[]; steps: Step[] } = useOutletContext();
  // const [step, setStep] = useState('');
  // const [selectedStep, setSelectedStep] = useState<SelectedStep>();
  const [selectedInterestPoint, setSelectedInterestPoint] =
    useState<SelectedInterestPoint>();
  const [interestpointToUpdate, setInterestPointToUpdate] =
    useState<SelectedInterestPoint>();
  const [days, setDays] = React.useState<number[]>([]);
  const [dayEditAvailable, setDayEditAvailable] = React.useState<boolean>(false);
  // const onChange = (e: any) => setTextValue(e.target.value);

  useEffect(() => {
    interestPoints.forEach((interestpoint: InterestPoint) => {
      interestpoint?.id === selectedId &&
        setSelectedInterestPoint(interestpoint);
      interestpoint?.id === selectedId &&
        setInterestPointToUpdate(interestpoint);
    });
    // steps.forEach((step: Step) => {
    //   step?.id === selectedId && setSelectedStep(step);
    //   // step?.id === selectedId && setStepToUpdate(step);
    // });
    // console.log(JSON.stringify(selectedInterestPoint, null, 2))
  }, [selectedId, interestPoints, selectedInterestPoint]);

  const queryClient = useQueryClient();

  const updateInterestPoint = useMutation(api.update, {
    onSuccess: (interestpoint, { id }) => {
      queryClient.setQueryData<InterestPoint[]>(
        ["interestPoints", id_travel],
        (interestPoints) =>
          interestPoints!.map((s) =>
            s.id === id ? { ...s, element: s.element } : s
          )
      );
    },
  });

  const {
    isLoading: stepIsLoading,
    isError: stepIsError,
    data: selectedStep,
    error: stepError,
  } = useQuery(["step", idTravel], () => api.getOne({ route: Step.routeName, hasToken: true, id: selectedInterestPoint!.id!, idTravel: id_travel }));


  // useEffect(() => {

  //   // if (selectedInterestPoint && selectedInterestPoint.id) {
  //   //   const _step = () => api.getOne({ route: Step.routeName, id: selectedInterestPoint.id, idTravel: id_travel });
  //   //   setSelectedStep(_step);
  //   // }

  //   // if(step) {
  //   //   setSelectedStep(_step);
  //   // }

  // }, [selectedInterestPoint]);

  useEffect(() => {
    console.log(interestpointToUpdate)
  }, [interestpointToUpdate])

  useEffect(() => {
    if (selectedStep && selectedStep.duration) {
      let _days: any = [];
      for (let i = 1; i <= selectedStep.duration; i++) {
        _days.push(i);
      }
      setDays(_days);
    }
  }, [selectedInterestPoint, selectedStep]);

  // const onTextChange = (e: any) => setTextValue(e.target.value);
  const handleCancel = () => navigate(-1);

  const handleSubmit = (event: any) => {
    // event.preventDefault();

    console.log(
      "ON SUBMIT : " + JSON.stringify(interestpointToUpdate, null, 2)
    );

    // selectedInterestPoint &&
    updateInterestPoint.mutate({
      route: InterestPoint.routeName,
      id: interestpointToUpdate?.id!,
      body: interestpointToUpdate!,
      idTravel: id_travel,
    });
    navigate(-1);
  };

  const onChangeStep = ({
    target: { name, value },
  }: SelectChangeEvent<string>) => {
    setInterestPointToUpdate({ ...interestpointToUpdate, [name]: value });
    setDayEditAvailable(true);
  };
  // const onChangeStep = (event: SelectChangeEvent<string>, child: React.ReactNode) => {
  //   // setStep(event.target.value);
  //   setInterestPointToUpdate({ ...interestpointToUpdate, [name]: value });
  // };

  const onChangeDays = async ({
    target: { name, value },
  }: SelectChangeEvent<string>) => {
    console.log("UPDATE SET" + value)
    // setInterestPointToUpdate({ [name]: value });
    setInterestPointToUpdate({
      ...interestpointToUpdate,
      [name]: value
    });
  };

  return (
    <Box>
      <Box
        sx={{
          backgroundColor: "primary.lighter",
          padding: 1,
          mb: 1,
          borderRadius: "4px",
        }}
      >
        <Typography
          textTransform="uppercase"
          color="primary.darker"
          ml={1}
          fontWeight="medium"
          variant="h6"
        >
          Modifier le point d'intérêt «{selectedInterestPoint?.element?.name}»
        </Typography>
      </Box>
      <Box
        sx={{
          backgroundColor: "primary.lighter",
          padding: 2,
          borderRadius: "4px",
        }}
        display="flex"
        flexDirection="column"
      >
        <FormControl>
          <TextField
            name="element"
            // required
            id="filled-required"
            label="Nom"
            variant="filled"
            sx={{ my: 2 }}
            placeholder={selectedInterestPoint?.element?.name}
            onChange={({
              target: { name, value },
            }: React.ChangeEvent<HTMLInputElement>) => {
              const element = interestpointToUpdate?.element;
              setInterestPointToUpdate({
                ...interestpointToUpdate,
                [name]: { ...element, name: value },
              });
            }}
            color="primary"
          />
          <TextField
            name="element"
            // required
            id="filled-required"
            label="Description"
            variant="filled"
            sx={{ my: 2 }}
            placeholder={selectedInterestPoint?.element?.description}
            onChange={({
              target: { name, value },
            }: React.ChangeEvent<HTMLInputElement>) => {
              setInterestPointToUpdate({
                ...interestpointToUpdate,
                [name]: value
              });
            }}
            color="primary"
          />
          <FormControl>
            <InputLabel id="interestpoint-step">Etape</InputLabel>
            <Select
              labelId="interestpoint-step"
              id="interestpoint-step"
              // value={selectedStep!.id!.toString()}
              autoWidth
              label="Age"
              name="id_step"
              onChange={onChangeStep}
            >
              {/* <MenuItem value="">
            <em>Sélectionner une étape</em>
          </MenuItem> */}
              {steps.map((step) => (
                <MenuItem value={step.id}>{step.element.name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {(selectedInterestPoint && (selectedInterestPoint.id_step || dayEditAvailable)) &&
            <Box sx={{ flex: 2, mt: 2 }}>
              <FormControl>
                {selectedInterestPoint.day ? selectedInterestPoint.day + "/" + selectedStep?.duration : "N/A"}
                <EventIcon />
                <Select
                  labelId="interestpoint-day"
                  id="interestpoint-day"
                  name="day"
                  autoWidth
                  defaultValue=""
                  onChange={onChangeDays}
                  input={<OutlinedInput label={"Jour"} />}
                // MenuProps={MenuProps}
                >
                  {days.map((option: any) => (
                    <MenuItem key={option} value={option}>
                      Jour {option}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
          }

          {/* <TextField
          name="duration"
          // required
          id="filled-required"
          label="Etape liée"
          variant="filled"
          sx={{ my: 2 }}
          type="select"
          // placeholder={selectedInterestPoint?.duration}
          onChange={onChange}
          color="primary"
        /> */}
          <Box mt={2}>
            <Button
              variant="contained"
              size="small"
              sx={{
                backgroundColor: "warning.darky",
                "&:hover": {
                  backgroundColor: "warning.main",
                  color: "warning.lighter",
                },
                color: "warning.lighter",
                borderColor: "warning.main",
                textAlign: "left",
                minHeight: 0,
                padding: "0.5rem",
                minWidth: "8rem",
              }}
              onClick={handleCancel}
            >
              Annuler
            </Button>
            <Button
              variant="contained"
              size="small"
              sx={{
                backgroundColor: "primary.darky",
                "&:hover": {
                  backgroundColor: "primary.main",
                  color: "primary.lighter",
                },
                color: "primary.lighter",
                borderColor: "primary.main",
                textAlign: "left",
                minHeight: 0,
                padding: "0.5rem",
                minWidth: "8rem",
                ml: 2,
              }}
              onClick={handleSubmit}
            >
              Valider
            </Button>
          </Box>
        </FormControl>
      </Box >
    </Box >
  );
};
