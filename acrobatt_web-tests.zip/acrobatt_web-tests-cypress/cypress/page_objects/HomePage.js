/// <reference types="cypress" />


export class HomePage {


    navigateTo() {
      cy.visit(`/`);

    }

    logout(){
      cy.get('[data-testid="LogoutIcon"]').click();
      cy.get("[data-cy=okButton]").click();
      cy.get('text').should('contain.text','MAPADORA')
    }
}