export type Item = {
  id: string;
  primary: string;
  secondary: string;
};
